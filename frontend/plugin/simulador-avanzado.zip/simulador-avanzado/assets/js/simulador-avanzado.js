document.addEventListener('DOMContentLoaded', function () {
    const editorContainer = document.getElementById('sim-avanzado-editor');
    const consoleEl = document.getElementById('sim-avanzado-console');
    const statusBadge = document.getElementById('sim-avanzado-status-badge');
    const ejecutarBtn = document.querySelector('.sim-avanzado-run');
    const limpiarBtn = document.querySelector('.sim-avanzado-clear');
    const vcdToggleBtn = document.getElementById('sim-avanzado-vcd-btn');
    const vcdPanel = document.getElementById('sim-avanzado-vcd-panel');
    const surferIframe = document.getElementById('sim-avanzado-surfer-iframe');
    const vcdTag = document.getElementById('vcd-filename-tag');
    const reloadVcdBtn = document.getElementById('sim-avanzado-reload-vcd');
    const closeVcdBtn = document.getElementById('sim-avanzado-close-vcd');

    if (!editorContainer || !consoleEl || !ejecutarBtn) {
        return;
    }

    let ws = null;
    let currentVcdUrl = null;
    let currentVcdFile = null;

    const defaultCode = `module tb_avanzado;
  reg clk;
  reg [3:0] count;

  initial begin
    $dumpfile("wave.vcd");
    $dumpvars(0, tb_avanzado);
    $display("QuestaSim/Icarus: inicio de simulación con volcado VCD");
    clk = 0;
    count = 0;
    #50;
    $display("Simulación finalizada. Formas de onda guardadas.");
    $finish;
  end

  always #5 clk = ~clk;

  always @(posedge clk) begin
    count <= count + 1;
    $display("Tiempo=%0t | clk=%b | count=%d", $time, clk, count);
  end
endmodule`;

    function updateStatus(connected) {
        if (!statusBadge) return;
        if (connected) {
            statusBadge.textContent = 'Conectado';
            statusBadge.className = 'status-indicator connected';
        } else {
            statusBadge.textContent = 'Desconectado';
            statusBadge.className = 'status-indicator disconnected';
        }
    }

    function addLine(message, type) {
        const line = document.createElement('div');
        line.className = 'sim-transcript-line ' + (type || 'ok');
        line.textContent = message;
        consoleEl.appendChild(line);
        consoleEl.scrollTop = consoleEl.scrollHeight;
    }

    function setTranscript(text, isError) {
        consoleEl.innerHTML = '';
        addLine(text, isError ? 'error' : 'ok');
    }

    function resetConsole(message) {
        consoleEl.innerHTML = '';
        addLine(message || '> Console transcript limpia.', 'ok');
    }

    function getEditorValue() {
        if (window.simAvanzadoEditor && typeof window.simAvanzadoEditor.getValue === 'function') {
            return window.simAvanzadoEditor.getValue();
        }
        return defaultCode;
    }

    function buildAbsoluteUrl(relativeOrAbs) {
        if (!relativeOrAbs) return '';
        if (relativeOrAbs.startsWith('http://') || relativeOrAbs.startsWith('https://')) {
            return relativeOrAbs;
        }
        const vcdBase = (typeof SIMULADOR_AVANZADO_CONFIG !== 'undefined' && SIMULADOR_AVANZADO_CONFIG.vcd_base_url)
            ? SIMULADOR_AVANZADO_CONFIG.vcd_base_url
            : 'http://localhost:8000';
        return vcdBase.replace(/\/$/, '') + '/' + relativeOrAbs.replace(/^\//, '');
    }

    function showVcdViewer(vcdUrl, vcdFile) {
        currentVcdUrl = buildAbsoluteUrl(vcdUrl);
        currentVcdFile = vcdFile || 'wave.vcd';

        if (vcdTag) {
            vcdTag.textContent = currentVcdFile;
        }

        if (vcdToggleBtn) {
            vcdToggleBtn.style.display = 'inline-flex';
        }

        if (vcdPanel) {
            vcdPanel.className = 'sim-vcd-panel-expanded';
        }

        const surferBaseUrl = (typeof SIMULADOR_AVANZADO_CONFIG !== 'undefined' && SIMULADOR_AVANZADO_CONFIG.surfer_url)
            ? SIMULADOR_AVANZADO_CONFIG.surfer_url
            : 'http://localhost:8000/surfer/index.html';

        function sendLoadCommand() {
            if (surferIframe && surferIframe.contentWindow && currentVcdUrl) {
                try {
                    surferIframe.contentWindow.postMessage({
                        command: 'LoadUrl',
                        url: currentVcdUrl
                    }, '*');
                } catch (e) {
                    console.error('Error al enviar postMessage a Surfer:', e);
                }
            }
        }

        if (surferIframe) {
            if (surferIframe.src === 'about:blank' || !surferIframe.src.includes('/surfer/')) {
                surferIframe.src = surferBaseUrl;
                surferIframe.onload = function () {
                    setTimeout(sendLoadCommand, 800);
                };
            } else {
                sendLoadCommand();
                setTimeout(sendLoadCommand, 600);
            }
        }

        addLine('> 📈 Forma de onda VCD detectada y cargada en Surfer WASM.', 'vcd-notify');
    }

    function hideVcdViewer() {
        if (vcdPanel) {
            vcdPanel.className = 'sim-vcd-panel-collapsed';
        }
    }

    function connectWebSocket() {
        const wsUrl = (typeof SIMULADOR_AVANZADO_CONFIG !== 'undefined' && SIMULADOR_AVANZADO_CONFIG.ws_url)
            ? SIMULADOR_AVANZADO_CONFIG.ws_url
            : 'ws://localhost:8000/ws';

        if (ws && ws.readyState === WebSocket.OPEN) {
            return;
        }

        ws = new WebSocket(wsUrl);

        ws.onopen = function () {
            updateStatus(true);
            setTranscript('> Conectado al servidor de simulación.', false);
            ws.send(JSON.stringify({ accion: 'check_vcd' }));
        };

        ws.onclose = function () {
            updateStatus(false);
            setTranscript('> WebSocket desconectado.', true);
        };

        ws.onerror = function () {
            updateStatus(false);
            setTranscript('> Error de conexión WebSocket con el backend.', true);
        };

        ws.onmessage = function (event) {
            let payload;
            try {
                payload = JSON.parse(event.data);
            } catch (error) {
                addLine(event.data, 'ok');
                return;
            }

            if (payload.status === 'error_compilacion' || payload.tipo === 'linter_error') {
                const errorMsg = payload.detalles || payload.transcript || 'Error de compilación.';
                setTranscript(errorMsg, true);
                return;
            }

            if (payload.status === 'compilado_ok' || payload.status === 'simulacion_ok') {
                setTranscript(payload.transcript || '✓ Simulación ejecutada correctamente.', false);
                if (payload.has_vcd && payload.vcd_url) {
                    showVcdViewer(payload.vcd_url, payload.vcd_file);
                }
                return;
            }

            if (payload.tipo === 'vcd_status') {
                if (payload.has_vcd && payload.vcd_url) {
                    showVcdViewer(payload.vcd_url, payload.vcd_file);
                }
                return;
            }

            if (payload.transcript) {
                addLine(payload.transcript, false);
            }

            if (payload.has_vcd && payload.vcd_url) {
                showVcdViewer(payload.vcd_url, payload.vcd_file);
            }
        };
    }

    function initMonaco() {
        if (window.simAvanzadoEditor) {
            return;
        }

        if (window.monaco && window.monaco.editor) {
            window.simAvanzadoEditor = monaco.editor.create(editorContainer, {
                value: defaultCode,
                language: 'verilog',
                theme: 'vs-dark',
                automaticLayout: true,
                minimap: { enabled: false },
                scrollBeyondLastLine: false,
                fontSize: 13,
                lineNumbersMinChars: 3
            });
            return;
        }

        const existingLoader = document.querySelector('script[data-sim-avanzado-monaco="true"]');
        if (existingLoader) {
            existingLoader.addEventListener('load', initMonaco, { once: true });
            return;
        }

        const loader = document.createElement('script');
        loader.src = 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.52.2/min/vs/loader.min.js';
        loader.setAttribute('data-sim-avanzado-monaco', 'true');
        loader.onload = function () {
            require.config({
                paths: {
                    vs: 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.52.2/min/vs'
                }
            });

            require(['vs/editor/editor.main'], function () {
                window.simAvanzadoEditor = monaco.editor.create(editorContainer, {
                    value: defaultCode,
                    language: 'verilog',
                    theme: 'vs-dark',
                    automaticLayout: true,
                    minimap: { enabled: false },
                    scrollBeyondLastLine: false,
                    fontSize: 13,
                    lineNumbersMinChars: 3
                });
            });
        };
        document.head.appendChild(loader);
    }

    initMonaco();
    connectWebSocket();

    ejecutarBtn.addEventListener('click', function () {
        const contenido = getEditorValue().trim();

        if (!contenido) {
            setTranscript('> Error: El banco de pruebas está vacío.', true);
            return;
        }

        if (!ws || ws.readyState !== WebSocket.OPEN) {
            connectWebSocket();
        }

        if (!ws || ws.readyState !== WebSocket.OPEN) {
            setTranscript('> WebSocket no disponible. Comprueba el backend.', true);
            return;
        }

        setTranscript('> Iniciando simulación...', false);
        ws.send(JSON.stringify({
            accion: 'simular',
            codigo: contenido,
            testbench: contenido
        }));
    });

    limpiarBtn.addEventListener('click', function () {
        resetConsole('> Console transcript limpia.');
        hideVcdViewer();
        if (window.simAvanzadoEditor) {
            window.simAvanzadoEditor.setValue(defaultCode);
        }
    });

    if (vcdToggleBtn) {
        vcdToggleBtn.addEventListener('click', function () {
            if (vcdPanel.classList.contains('sim-vcd-panel-expanded')) {
                hideVcdViewer();
            } else if (currentVcdUrl) {
                showVcdViewer(currentVcdUrl, currentVcdFile);
            }
        });
    }

    if (reloadVcdBtn) {
        reloadVcdBtn.addEventListener('click', function () {
            if (currentVcdUrl) {
                showVcdViewer(currentVcdUrl, currentVcdFile);
            }
        });
    }

    if (closeVcdBtn) {
        closeVcdBtn.addEventListener('click', function () {
            hideVcdViewer();
        });
    }
});
