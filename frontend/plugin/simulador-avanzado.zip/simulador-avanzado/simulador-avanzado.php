<?php
/**
 * Plugin Name: SIMULADOR-AVANZADO
 * Description: Simulador avanzado con tres paneles: banco de pruebas (izq), console transcript (der) y visor de formas de onda Surfer VCD (inferior full-width expandible).
 * Version: 1.0.0
 * Author: Antigravity
 */

if (!defined('ABSPATH')) {
    exit;
}

class SimuladorAvanzadoPlugin {
    public static function init() {
        add_shortcode('simulador_avanzado', array(__CLASS__, 'render_shortcode'));
        add_action('wp_enqueue_scripts', array(__CLASS__, 'enqueue_assets'));
    }

    public static function enqueue_assets() {
        wp_enqueue_style(
            'simulador-avanzado-style',
            plugin_dir_url(__FILE__) . 'assets/css/simulador-avanzado.css',
            array(),
            '1.0.0'
        );

        wp_enqueue_script(
            'simulador-avanzado-script',
            plugin_dir_url(__FILE__) . 'assets/js/simulador-avanzado.js',
            array(),
            '1.0.0',
            true
        );

        wp_localize_script('simulador-avanzado-script', 'SIMULADOR_AVANZADO_CONFIG', array(
            'ws_url' => apply_filters('simulador_avanzado_ws_url', 'ws://localhost:8000/ws'),
            'surfer_url' => apply_filters('simulador_avanzado_surfer_url', 'http://localhost:8000/surfer/index.html'),
            'vcd_base_url' => apply_filters('simulador_avanzado_vcd_base_url', 'http://localhost:8000')
        ));
    }

    public static function render_shortcode() {
        ob_start();
        ?>
        <div class="simulador-avanzado-plugin">
            <div class="simulador-avanzado-header">
                <div class="simulador-avanzado-title">
                    <span class="sim-title-main">SIMULADOR-AVANZADO</span>
                    <span class="sim-badge">SURFER VCD</span>
                </div>
                <div class="simulador-avanzado-actions">
                    <button type="button" class="sim-avanzado-run">Ejecutar Simulación</button>
                    <button type="button" class="sim-avanzado-toggle-vcd secondary" id="sim-avanzado-vcd-btn" style="display: none;">📊 Formas de Onda</button>
                    <button type="button" class="sim-avanzado-clear secondary">Limpiar</button>
                </div>
            </div>

            <!-- FILA SUPERIOR: Editor (Izq) y Consola (Der) -->
            <div class="simulador-avanzado-top-layout">
                <section class="sim-panel sim-panel-left">
                    <div class="panel-title">
                        <span>Banco de pruebas (Monaco)</span>
                        <span class="panel-subtitle">Verilog / SystemVerilog</span>
                    </div>
                    <div id="sim-avanzado-editor" aria-label="Editor de banco de pruebas"></div>
                </section>

                <section class="sim-panel sim-panel-right">
                    <div class="panel-title">
                        <span>Console Transcript (QuestaSim / Icarus)</span>
                        <span id="sim-avanzado-status-badge" class="status-indicator">Desconectado</span>
                    </div>
                    <div id="sim-avanzado-console" class="sim-console" aria-live="polite">
                        <div class="sim-transcript-line">&gt; Esperando ejecución de simulación...</div>
                    </div>
                </section>
            </div>

            <!-- FILA INFERIOR (FULL-WIDTH): Visor de Ondas Surfer WASM -->
            <div id="sim-avanzado-vcd-panel" class="sim-vcd-panel-collapsed">
                <div class="vcd-panel-header">
                    <div class="vcd-title-group">
                        <span class="vcd-icon">📈</span>
                        <span class="vcd-title">Visor de Formas de Onda (Surfer WebAssembly)</span>
                        <span id="vcd-filename-tag" class="vcd-filename-tag">wave.vcd</span>
                    </div>
                    <div class="vcd-panel-controls">
                        <button type="button" id="sim-avanzado-reload-vcd" class="vcd-btn-sm" title="Recargar Ondas">🔄 Recargar</button>
                        <button type="button" id="sim-avanzado-close-vcd" class="vcd-btn-sm danger" title="Cerrar Visor">✖ Cerrar</button>
                    </div>
                </div>
                <div class="vcd-iframe-container">
                    <iframe id="sim-avanzado-surfer-iframe" src="about:blank" title="Visor Surfer WASM"></iframe>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}

SimuladorAvanzadoPlugin::init();
