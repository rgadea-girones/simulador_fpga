/**
 * Simulador OOP SystemVerilog (Has-A / Is-A) - Client Engine
 * 3 Frames Layout: Testbench (sup-izq), Design (sup-der), Transcript (inf)
 */

(function () {
    let ws = null;

    // --- MANEJO DE ESTADOS Y BOTONES ---
    function cambiarEstadoBotones(bloquear) {
        const botones = document.querySelectorAll('.sim-btn');
        botones.forEach(btn => btn.disabled = bloquear);
    }

    function mostrarCargando(tipo) {
        cambiarEstadoBotones(true);
        if (tipo === 'linter') {
            const btn = document.getElementById('btn-linter');
            if (btn) btn.innerText = '🔍 Comprobando...';
        } else if (tipo === 'compilar') {
            const sp = document.getElementById('btn-spinner-compilar');
            const tx = document.getElementById('btn-compilar-texto');
            if (sp) sp.style.display = 'inline-block';
            if (tx) tx.innerText = 'Compilando...';
        } else if (tipo === 'simular') {
            const sp = document.getElementById('btn-spinner-simular');
            const tx = document.getElementById('btn-simular-texto');
            if (sp) sp.style.display = 'inline-block';
            if (tx) tx.innerText = 'Simulando...';
        }
    }

    function restaurarEstadoBotones() {
        cambiarEstadoBotones(false);
        
        const btnLinter = document.getElementById('btn-linter');
        if (btnLinter) btnLinter.innerText = '🔍 Comprobar (Linter)';

        const spCompilar = document.getElementById('btn-spinner-compilar');
        const txCompilar = document.getElementById('btn-compilar-texto');
        if (spCompilar) spCompilar.style.display = 'none';
        if (txCompilar) txCompilar.innerText = '✅ Verificar';

        const spSimular = document.getElementById('btn-spinner-simular');
        const txSimular = document.getElementById('btn-simular-texto');
        if (spSimular) spSimular.style.display = 'none';
        if (txSimular) txSimular.innerText = '▶️ Simular';
    }

    function initSimulador() {
        const containerDesign = document.getElementById('editor_design');
        const containerTB = document.getElementById('editor_tb');
        if (!containerDesign || !containerTB) return;

        // --- 1. WEBSOCKET ---
        const wsUrl = (typeof SV_HAS_A_IS_A_CONFIG !== 'undefined' && SV_HAS_A_IS_A_CONFIG.ws_url)
            ? SV_HAS_A_IS_A_CONFIG.ws_url
            : 'ws://localhost:8000/ws';

        ws = new WebSocket(wsUrl);
        const est = document.getElementById('estado_ws');

        ws.onopen = () => { 
            if (est) { 
                est.innerText = "🟢 CONECTADO"; 
                est.style.color = "#2ecc71"; 
            } 
        };
        ws.onclose = () => { 
            if (est) { 
                est.innerText = "🔴 DESCONECTADO"; 
                est.style.color = "#e74c3c"; 
            }
            restaurarEstadoBotones();
        };
        ws.onerror = () => { restaurarEstadoBotones(); };

        ws.onmessage = (e) => {
            let r;
            try { r = JSON.parse(e.data); } catch (err) { return; }

            if (r.status || r.tipo === "error") {
                restaurarEstadoBotones();
            }

            if (r.status === "error_compilacion" || r.tipo === "linter_error") {
                if (est) { est.innerText = "🔴 ERROR EN CÓDIGO"; est.style.color = "#e74c3c"; }
                const errorMsg = r.detalles || r.transcript || "Error detectado.";
                setTranscript(errorMsg, true);
                aplicarLinter(errorMsg);
            } 
            else if (r.status === "linter_ok") {
                if (est) { est.innerText = "🟢 CÓDIGO CORRECTO"; est.style.color = "#2ecc71"; }
                limpiarMarcadores();
                setTranscript(r.transcript || "✓ Sintaxis verificada correctamente sin errores.", false);
            }
            else if (r.status === "compilado_ok") {
                if (est) { est.innerText = "🟢 COMPILADO OK"; est.style.color = "#2ecc71"; }
                limpiarMarcadores();
                setTranscript(r.transcript || "=== Compilación finalizada correctamente ===", false);
            } 
            else if (r.status === "simulacion_ok") {
                if (est) { est.innerText = "🟢 SIMULACIÓN EN EJECUCIÓN"; est.style.color = "#2ecc71"; }
                setTranscript(r.transcript || "=== Simulación iniciada ===", false);
            }
            else if (r.tipo === "transcript") {
                appendTranscript(r.contenido || r.transcript, false);
            }
        };

        // --- 2. MONACO IFRAMES GENERATOR ---
        function crearFrameMonaco(container, idInstancia, codigoInicial) {
            container.innerHTML = '';
            const iframe = document.createElement('iframe');
            iframe.style.width = '100%';
            iframe.style.height = '100%';
            iframe.style.border = 'none';
            container.appendChild(iframe);

            const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
            const htmlContent = `
                <!DOCTYPE html>
                <html>
                <head>
                    <style>
                        html, body, #editor-internal {
                            width: 100%; height: 100%; margin: 0; padding: 0;
                            overflow: hidden; background-color: #1e1e1e;
                        }
                    </style>
                    <script src="https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.36.1/min/vs/loader.min.js"></script>
                </head>
                <body>
                    <div id="editor-internal"></div>
                    <script>
                        require.config({ paths: { 'vs': 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.36.1/min/vs' } });
                        require(['vs/editor/editor.main'], function () {
                            window.editor = monaco.editor.create(document.getElementById('editor-internal'), {
                                value: \`${codigoInicial}\`,
                                language: 'verilog',
                                theme: 'vs-dark',
                                automaticLayout: true,
                                minimap: { enabled: false }
                            });

                            window.editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS, function () {
                                window.parent.postMessage({ accion: 'linter' }, '*');
                            });
                        });
                    </script>
                </body>
                </html>
            `;

            iframeDoc.open();
            iframeDoc.write(htmlContent);
            iframeDoc.close();

            return iframe;
        }

        // --- 3. DEFINICIÓN DE EJEMPLOS UVM DIAPOSITIVAS ---
        const examples = {
            clases: {
                design: `// Slide 3: Clases y Objetos
class BusTran;
    // Propiedades de la clase (o variables)
    logic [31:0] addr;
    logic [31:0] crc;
    logic [31:0] data[8];

    // Métodos de la clase
    task display();
        $display("BusTran: addr = %0h, crc = %0h", addr, crc);
    endtask : display

    function void compute_crc();
        // Operación XOR de reducción para simplificar la simulación
        crc = addr ^ data[0];
    endfunction : compute_crc
endclass : BusTran`,
                tb: `module tb_classes;
    initial begin
        $display("=== Simulación: Declaración de Clase (Slide 3) ===");
        // La simulación de instancias de esta clase se realiza en el siguiente ejemplo
    end
endmodule`
            },
            objetos: {
                design: `// Slide 4: Objetos
class BusTran;
    logic [31:0] addr;
    logic [31:0] crc;
    logic [31:0] data[8];

    task display();
        $display("BusTran: addr = %0h, crc = %0h", addr, crc);
    endtask : display

    function void compute_crc();
        crc = addr ^ data[0];
    endfunction : compute_crc
endclass : BusTran`,
                tb: `module tb_objects;
    initial begin
        $display("=== Simulación: Creación de Objetos (Slide 4) ===");
        begin
            BusTran btran; // Declara un handle null (valor null)
            btran = new;   // Crea un objeto BusTran y hace que btran apunte a él
                           // Inicializa todas las variables del objeto a 'X o valor por defecto
            
            btran.addr = 32'h127;
            btran.data[0] = 32'hA5A5;
            btran.compute_crc();
            
            btran.display();
        end
    end
endmodule`
            },
            constructor_sin_args: {
                design: `// Slide 5 Izq: Constructor sin argumentos
class BusTran;
    logic [31:0] addr;
    logic [31:0] crc;
    logic [31:0] data[8];

    // Constructor sin argumentos
    function new();
        addr = 0;
        foreach (data[i]) data[i] = 0;
    endfunction : new

    task display();
        $display("BusTran (Sin Args): addr = %0d, data[0] = %0d", addr, data[0]);
    endtask
endclass : BusTran`,
                tb: `module tb_constructor_sin_args;
    initial begin
        $display("=== Simulación: Constructor sin argumentos (Slide 5 Izq) ===");
        begin
            BusTran btran;
            btran = new(); // Llama al constructor personalizado
            btran.display();
        end
    end
endmodule`
            },
            constructor_con_args: {
                design: `// Slide 5 Der: Constructor con argumentos
class BusTran;
    logic [31:0] addr;
    logic [31:0] crc;
    logic [31:0] data[8];

    // Constructor con argumentos y valores por defecto
    function new(logic [31:0] addr = 0, logic [31:0] val = 0);
        this.addr = addr;
        foreach (this.data[i]) this.data[i] = val;
    endfunction : new

    task display();
        $display("BusTran (Con Args): addr = %0h, data[0-7] = %0h", addr, data[0]);
    endtask
endclass : BusTran`,
                tb: `module tb_constructor_con_args;
    initial begin
        $display("=== Simulación: Constructor con argumentos (Slide 5 Der) ===");
        begin
            BusTran btran;
            btran = new(.addr('h42), .val('hFF)); // Llama especificando argumentos
            btran.display();
        end
    end
endmodule`
            },
            gestion_memoria: {
                design: `// Slide 6: Gestión de la memoria
class BusTran;
    logic [31:0] addr;
    
    function new(logic [31:0] addr = 0);
        this.addr = addr;
    endfunction
endclass : BusTran`,
                tb: `module tb_memory_management;
    task do_something;
        BusTran b;
        b = new('h111);
        $display("  [do_something] b creado con addr = %0h", b.addr);
    endtask : do_something

    initial begin
        $display("=== Simulación: Gestión de Memoria (Slide 6) ===");
        begin
            BusTran btran;
            $display("1. Creando primer objeto...");
            btran = new; // Asigna memoria para un nuevo objeto BusTran
            
            $display("2. Creando segundo objeto (libera el anterior)...");
            btran = new; // Asigna un segundo objeto, el primero se marca para recolección
            
            $display("3. Asignando handle a null (libera memoria)...");
            btran = null; // Libera el segundo objeto
            
            $display("4. Ejecutando tarea con ámbito local:");
            do_something(); // El objeto creado dentro sale de ámbito al terminar
            $display("Fin de la demostración.");
        end
    end
endmodule`
            },
            variables_estaticas: {
                design: `// Slide 8: Variables estáticas de clase
class BusTran;
    // Variable estática de clase compartida por todas las instancias
    static int count = 0;
    
    logic [31:0] addr;
    int id;

    function new(logic [31:0] addr = 0);
        id = ++count; // Comienza en 1 e incrementa en cada new
        this.addr = addr;
    endfunction : new
endclass : BusTran`,
                tb: `module tb_static_variables;
    initial begin
        $display("=== Simulación: Variables Estáticas (Slide 8) ===");
        begin
            BusTran::count = 10; // Acceso directo sin instanciar
            $display("Count inicializado a %0d", BusTran::count);

            begin
                BusTran b1, b2;
                b1 = new('hAAAA); // b1.id = 11
                $display("b1 creado: id=%0d, count=%0d", b1.id, b1.count);
                
                b2 = new('hBBBB); // b2.id = 12
                $display("b2 creado: id=%0d, count=%0d", b2.id, b2.count);
            end
        end
    end
endmodule`
            },
            variables_constantes: {
                design: `// Slide 9: Variables de clase constantes
class Packet;
    // Constante global/estática
    const int MAX_SIZE = 1024;
    
    // Constante de instancia (se asigna una única vez en el constructor)
    const int SIZE;
    byte payload[];

    function new(int size_in = 100);
        SIZE = (size_in > MAX_SIZE) ? MAX_SIZE : size_in;
        payload = new[SIZE];
    endfunction : new
endclass : Packet`,
                tb: `module tb_constant_variables;
    initial begin
        $display("=== Simulación: Variables Constantes (Slide 9) ===");
        begin
            Packet p1 = new(50);
            Packet p2 = new(2000); // Superará el max size
            
            $display("Packet 1: SIZE=%0d (Max: %0d)", p1.SIZE, p1.MAX_SIZE);
            $display("Packet 2: SIZE=%0d (Limitado por MAX_SIZE)", p2.SIZE);
        end
    end
endmodule`
            },
            metodos_estaticos: {
                design: `// Slide 10: Métodos Estáticos
class BusTran;
    static int count = 0;
    
    // Método estático. No puede acceder a miembros no estáticos.
    static function int next_id();
        next_id = ++count;
    endfunction : next_id
endclass : BusTran`,
                tb: `module tb_static_methods;
    initial begin
        $display("=== Simulación: Métodos Estáticos (Slide 10) ===");
        begin
            int next;
            next = BusTran::next_id(); // Se llama sin crear ningún objeto
            $display("ID siguiente obtenido estáticamente: %0d", next);
        end
    end
endmodule`
            },
            encapsulacion: {
                design: `// Slide 11 & 12: Encapsulación y Acceso Local/Protected
class BusTran;
    // local: Solo accesible dentro de la clase
    local int id;
    
    function new(int id);
        this.id = id;
    endfunction

    // Método público
    function int compare_id(BusTran b);
        compare_id = (this.id == b.id); // Acceso legal a b.id desde métodos de la misma clase
    endfunction : compare_id
endclass : BusTran`,
                tb: `module tb_encapsulation;
    initial begin
        $display("=== Simulación: Encapsulación (Slide 11) ===");
        begin
            BusTran b1 = new(45);
            BusTran b2 = new(45);
            
            // $display("b1.id = %0d", b1.id); // ILEGAL: id es local.
            if (b1.compare_id(b2)) begin
                $display("Los IDs de las transacciones coinciden!");
            end else begin
                $display("Los IDs son diferentes.");
            end
        end
    end
endmodule`
            },
            relacion_has_a: {
                design: `// Slide 13: Subclases (Relación "Has a")
class Statistics;
    time start_time;
    static int ntrans = 0;

    task start();
        start_time = $time;
    endtask

    function time duration();
        ntrans++;
        return $time - start_time;
    endfunction
endclass : Statistics

class BusTran;
    logic [31:0] addr;
    // Contiene una instancia de Statistics (Relación HAS-A)
    Statistics stats;

    function new();
        stats = new(); // Crea el objeto embebido
    endfunction : new

    task send_packet();
        stats.start();
        #25; // Simular retraso de transmisión
        $display("Transmisión finalizada. Duración: %0t ns (Total Transacciones: %0d)", stats.duration(), stats.ntrans);
    endtask : send_packet
endclass : BusTran`,
                tb: `module tb_has_a;
    initial begin
        $display("=== Simulación: Relación 'Has a' (Slide 13) ===");
        begin
            BusTran btran = new();
            btran.send_packet();
        end
    end
endmodule`
            },
            relacion_is_a: {
                design: `// Slide 14 & 15: Clases Derivadas (Relación "Is a")
class BusTran;
    logic [31:0] addr;
    int id;
    
    function new();
        id = 99;
    endfunction
endclass : BusTran

// Clase derivada (Relación IS-A)
class PCITran extends BusTran;
    logic [31:0] pci_data;

    function new();
        super.new(); // Llamada obligatoria al constructor del padre
        pci_data = 32'hC0DE;
    endfunction : new
endclass : PCITran`,
                tb: `module tb_is_a;
    initial begin
        $display("=== Simulación: Herencia 'Is a' (Slide 14-15) ===");
        begin
            BusTran b;
            PCITran p;
            
            p = new();
            b = p; // Upcasting legal y seguro (Handle Padre -> Objeto Hijo)
            
            $display("ID heredado en PCITran: %0d", p.id);
            $display("pci_data en PCITran: %0h", p.pci_data);
            $display("ID a través de handle base (Upcasting): %0d", b.id);
        end
    end
endmodule`
            },
            downcasting: {
                design: `// Slide 16: Downcasting seguro con $cast
class MiClaseBase;
    virtual function void print_tipo();
        $display("Soy un objeto MiClaseBase");
    endfunction
endclass

class MiClaseDerivada extends MiClaseBase;
    function void print_tipo();
        $display("Soy un objeto MiClaseDerivada (Hijo)");
    endfunction
    
    function void metodo_hijo();
        $display("Método exclusivo del hijo ejecutado con éxito.");
    endfunction
endclass`,
                tb: `module tb_downcasting;
    initial begin
        $display("=== Simulación: Downcasting seguro ($cast) (Slide 16) ===");
        begin
            MiClaseBase handle_base;
            MiClaseDerivada handle_derivado;
            MiClaseDerivada obj_derivado = new();

            handle_base = obj_derivado; // Upcasting (Automático y Seguro)

            // handle_derivado = handle_base; // ILEGAL: Error de compilación en asignación directa.
            
            // Recuperamos el handle del hijo de forma segura
            if ($cast(handle_derivado, handle_base)) begin
                $display("¡Downcasting exitoso!");
                handle_derivado.metodo_hijo();
            end else begin
                $display("Error: Downcasting fallido.");
            end
        end
    end
endmodule`
            },
            shallow_copy: {
                design: `// Slide 18: Shallow Copy (Copia Superficial)
class Header;
    int len = 15;
endclass

class Packet;
    Header hdr;
    int id;

    function new();
        id = 1;
        hdr = new();
    endfunction
endclass`,
                tb: `module tb_shallow_copy;
    initial begin
        $display("=== Simulación: Copia Superficial (Slide 18) ===");
        begin
            Packet p1 = new();
            Packet p2;
            
            $display("[Inicial] p1.id=%0d, p1.hdr.len=%0d", p1.id, p1.hdr.len);
            
            // Creamos copia superficial
            p2 = new p1;
            $display("[Copia] p2.id=%0d, p2.hdr.len=%0d", p2.id, p2.hdr.len);
            
            // Modificamos a través del clon
            p2.hdr.len = 99; // Modifica el objeto Header compartido
            p2.id = 25;      // Modifica la copia del tipo simple
            
            $display("--- Después de modificar p2 ---");
            $display("[Resultado p2] p2.id=%0d, p2.hdr.len=%0d", p2.id, p2.hdr.len);
            $display("[Resultado p1] p1.id=%0d, p1.hdr.len=%0d (¡Cabecera compartida modificada!)", p1.id, p1.hdr.len);
        end
    end
endmodule`
            },
            deep_copy: {
                design: `// Slide 20: Deep Copy (Copia Profunda)
class Header;
    int len = 15;
    
    function void copy(Header other);
        this.len = other.len;
    endfunction
endclass

class Packet;
    Header hdr;
    int id;

    function new();
        id = 1;
        hdr = new();
    endfunction

    // Función de copia profunda personalizada
    function void copy(Packet other);
        this.id = other.id;
        this.hdr.copy(other.hdr); // Copia profunda explícita del objeto embebido
    endfunction
endclass`,
                tb: `module tb_deep_copy;
    initial begin
        $display("=== Simulación: Copia Profunda (Slide 20) ===");
        begin
            Packet p1 = new();
            Packet p2 = new(); // Instancia destino
            
            $display("[Inicial] p1.id=%0d, p1.hdr.len=%0d", p1.id, p1.hdr.len);
            
            // Copia profunda
            p2.copy(p1);
            $display("[Copia] p2.id=%0d, p2.hdr.len=%0d", p2.id, p2.hdr.len);
            
            p2.hdr.len = 99;
            $display("--- Después de modificar p2 ---");
            $display("[Resultado p2] p2.id=%0d, p2.hdr.len=%0d", p2.id, p2.hdr.len);
            $display("[Resultado p1] p1.id=%0d, p1.hdr.len=%0d (¡Permanece intacto!)", p1.id, p1.hdr.len);
        end
    end
endmodule`
            },
            clonado: {
                design: `// Slide 22: Clonado con .clone()
class Header;
    int len = 15;
    function void copy(Header other);
        this.len = other.len;
    endfunction
endclass

class Packet;
    Header hdr;
    int id;

    function new();
        id = 1;
        hdr = new();
    endfunction

    function void copy(Packet other);
        this.id = other.id;
        this.hdr.copy(other.hdr);
    endfunction

    // El método clone devuelve una nueva copia exacta
    function Packet clone();
        clone = new();
        clone.copy(this);
    endfunction
endclass`,
                tb: `module tb_clonado;
    initial begin
        $display("=== Simulación: Clonado (Slide 22) ===");
        begin
            Packet p1 = new();
            Packet p2;
            
            $display("[Inicial] p1.id=%0d, p1.hdr.len=%0d", p1.id, p1.hdr.len);
            
            p2 = p1.clone(); // Crea e inicializa el duplicado al instante
            $display("[Copia] p2.id=%0d, p2.hdr.len=%0d", p2.id, p2.hdr.len);
            
            p2.hdr.len = 99;
            $display("--- Después de modificar p2 ---");
            $display("[Resultado p2] p2.id=%0d, p2.hdr.len=%0d", p2.id, p2.hdr.len);
            $display("[Resultado p1] p1.id=%0d, p1.hdr.len=%0d", p1.id, p1.hdr.len);
        end
    end
endmodule`
            },
            metodos_virtuales: {
                design: `// Slide 23: Métodos Virtuales y Polimorfismo
class Animal;
    // Sin la palabra clave 'virtual', la llamada se resolvería en compilación (Upcasting erróneo)
    virtual function void hacerSonido();
        $display("Sonido genérico de animal");
    endfunction
endclass

class Perro extends Animal;
    function void hacerSonido();
        $display("Guau!");
    endfunction
endclass`,
                tb: `module tb_virtual_methods;
    initial begin
        $display("=== Simulación: Métodos Virtuales (Slide 23) ===");
        begin
            Animal a;
            Perro p = new();
            
            a = p; // Upcasting
            
            a.hacerSonido(); // Gracias a 'virtual' en la clase base, invoca el método del hijo ("Guau!")
        end
    end
endmodule`
            }
        };

        const iframeTB = crearFrameMonaco(containerTB, 'tb', examples.clases.tb);
        const iframeDesign = crearFrameMonaco(containerDesign, 'design', examples.clases.design);

        // Actualizar editores al seleccionar un ejemplo
        const selectEjemplo = document.getElementById('ejemplos-has-a-is-a');
        if (selectEjemplo) {
            selectEjemplo.addEventListener('change', (e) => {
                const ej = examples[e.target.value];
                if (ej) {
                    if (iframeDesign.contentWindow && iframeDesign.contentWindow.editor) {
                        iframeDesign.contentWindow.editor.setValue(ej.design);
                    }
                    if (iframeTB.contentWindow && iframeTB.contentWindow.editor) {
                        iframeTB.contentWindow.editor.setValue(ej.tb);
                    }
                    limpiarMarcadores();
                    setTranscript("=== Código cargado desde ejemplos ===", false);
                }
            });
        }

        // --- 4. ACCIONES Y ENLACES ---
        window.addEventListener('message', (event) => {
            if (!event.data || !event.data.accion) return;
            if (event.data.accion === 'linter') {
                ejecutarLinter();
            }
        });

        function obtenerCodigo(iframe) {
            if (iframe && iframe.contentWindow && iframe.contentWindow.editor) {
                return iframe.contentWindow.editor.getValue();
            }
            return '';
        }

        function setTranscript(texto, esError = false) {
            const transcript = document.getElementById('simulation-transcript');
            if (!transcript) return;
            const color = esError ? '#e74c3c' : '#2ecc71';
            transcript.innerHTML = `<span style="color: ${color};">${texto}</span>`;
            transcript.scrollTop = transcript.scrollHeight;
        }

        function appendTranscript(texto, esError = false) {
            const transcript = document.getElementById('simulation-transcript');
            if (!transcript) return;
            const color = esError ? '#e74c3c' : '#2ecc71';
            transcript.innerHTML += `\n<span style="color: ${color};">${texto}</span>`;
            transcript.scrollTop = transcript.scrollHeight;
        }

        function aplicarLinter(errorText) {
            if (!errorText) return;
            [iframeDesign, iframeTB].forEach(iframe => {
                if (!iframe.contentWindow || !iframe.contentWindow.monaco) return;
                const win = iframe.contentWindow;
                const markers = [];
                const regex = /(?:[a-zA-Z0-9_\-\.]+\.(?:v|sv))\((\d+)\):\s*(.*)/gi;
                let m;

                while ((m = regex.exec(errorText)) !== null) {
                    markers.push({
                        startLineNumber: parseInt(m[1], 10),
                        startColumn: 1,
                        endLineNumber: parseInt(m[1], 10),
                        endColumn: 1000,
                        message: m[2].trim(),
                        severity: win.monaco.MarkerSeverity.Error
                    });
                }
                win.monaco.editor.setModelMarkers(win.editor.getModel(), 'verilog', markers);
            });
        }

        function limpiarMarcadores() {
            [iframeDesign, iframeTB].forEach(iframe => {
                if (iframe.contentWindow && iframe.contentWindow.monaco && iframe.contentWindow.editor) {
                    const win = iframe.contentWindow;
                    win.monaco.editor.setModelMarkers(win.editor.getModel(), 'verilog', []);
                }
            });
        }

        // --- ACCIONES WEBSOCKET ---
        function ejecutarLinter() {
            const codeDesign = obtenerCodigo(iframeDesign);
            const codeTB = obtenerCodigo(iframeTB);

            if (!ws || ws.readyState !== WebSocket.OPEN) {
                setTranscript("❌ Error: WebSocket desconectado.", true);
                return;
            }

            mostrarCargando('linter');
            limpiarMarcadores();
            setTranscript("🔍 Comprobando sintaxis con vlog -lint...", false);

            ws.send(JSON.stringify({
                accion: "linter",
                codigo: codeDesign,
                testbench: codeTB
            }));
        }

        function compilarCodigo() {
            const codeDesign = obtenerCodigo(iframeDesign);
            const codeTB = obtenerCodigo(iframeTB);

            if (!ws || ws.readyState !== WebSocket.OPEN) {
                setTranscript("❌ Error: WebSocket desconectado.", true);
                return;
            }

            mostrarCargando('compilar');
            limpiarMarcadores();
            setTranscript("⚙️ Compilando módulos con vlog...", false);

            ws.send(JSON.stringify({
                accion: "compilar",
                codigo: codeDesign,
                testbench: codeTB
            }));
        }

        function simularCodigo() {
            const codeDesign = obtenerCodigo(iframeDesign);
            const codeTB = obtenerCodigo(iframeTB);

            if (!ws || ws.readyState !== WebSocket.OPEN) {
                setTranscript("❌ Error: WebSocket desconectado.", true);
                return;
            }

            mostrarCargando('simular');
            setTranscript("▶️ Iniciando simulación...", false);

            ws.send(JSON.stringify({
                accion: "simular",
                codigo: codeDesign,
                testbench: codeTB
            }));
        }

        // --- BINDINGS ---
        const btnLinter = document.getElementById('btn-linter');
        if (btnLinter) btnLinter.addEventListener('click', ejecutarLinter);

        const btnCompilar = document.getElementById('btn-compilar');
        if (btnCompilar) btnCompilar.addEventListener('click', compilarCodigo);

        const btnSimular = document.getElementById('btn-simular');
        if (btnSimular) btnSimular.addEventListener('click', simularCodigo);
    }

    if (document.readyState === 'complete' || document.readyState === 'interactive') {
        initSimulador();
    } else {
        document.addEventListener('DOMContentLoaded', initSimulador);
    }
})();
