<?php
/**
 * Plugin Name: Evaluacion Aserciones
 * Description: Evaluacion automatica de contadores up/down modulo 13 con identificacion de alumno, transcript y correccion por evidencia.
 * Version: 1.0.0
 * Author: Antigravity
 */

if (!defined('ABSPATH')) {
    exit;
}

class EvaluacionAsercionesPlugin {
    public static function init() {
        add_shortcode('evaluacion_aserciones', array(__CLASS__, 'render_shortcode'));
        add_action('init', array(__CLASS__, 'register_content_type'));
        add_action('rest_api_init', array(__CLASS__, 'register_rest_routes'));
    }

    public static function register_content_type() {
        register_post_type('eva_report', array(
            'labels' => array(
                'name' => 'Eva Reports',
                'singular_name' => 'Eva Report'
            ),
            'public' => false,
            'show_ui' => false,
            'show_in_menu' => false,
            'show_in_rest' => false,
            'supports' => array('title', 'editor'),
            'capability_type' => 'post',
            'map_meta_cap' => true,
            'has_archive' => false,
            'rewrite' => false,
            'query_var' => false,
            'exclude_from_search' => true
        ));
    }

    private static function get_current_user_payload() {
        $user = wp_get_current_user();
        if (!$user || !$user->exists()) {
            return array();
        }

        return array(
            'user_id' => $user->ID,
            'display_name' => $user->display_name,
            'user_login' => $user->user_login,
            'user_email' => $user->user_email
        );
    }

    private static function get_task_bank() {
      return array_slice(array(
            array(
                'id' => 'E1',
                'title' => 'Contador A con terminal_count_en mal',
                'summary' => 'Comparar dos contadores up/down modulo 13 con enable, updown, reset_n y areset_n.',
                'truth' => 'a_bad_b_ok',
                'transcript_lines' => array(
                    '[E1][stimulus] enable=0 updown=1 reset_n=1 areset_n=1 count_ref=12',
                    '[E1][A] count=12 terminal_count_en=1 terminal_count_free=1 -> MISMATCH: terminal_count_en no depende de enable.',
                    '[E1][B] count=12 terminal_count_en=0 terminal_count_free=1 -> OK.',
                    '[E1][checker] Decision: solo el contador A es erroneo.'
                ),
                'counter_a' => <<<'SV'
module up_down_counter_a(
  input  logic clk,
  input  logic enable,
  input  logic updown,
  input  logic reset_n,
  input  logic areset_n,
  output logic terminal_count_en,
  output logic terminal_count_free,
  output logic [3:0] count
);
  always_ff @(posedge clk or negedge areset_n) begin
    if (!areset_n) count <= 4'd0;
    else if (!reset_n) count <= 4'd0;
    else if (enable) begin
      if (updown) count <= (count == 4'd12) ? 4'd0 : count + 4'd1;
      else count <= (count == 4'd0) ? 4'd12 : count - 4'd1;
    end
  end
  assign terminal_count_free = (updown && (count == 4'd12)) || (!updown && (count == 4'd0));
  assign terminal_count_en = terminal_count_free;
endmodule
SV,
                'counter_b' => <<<'SV'
module up_down_counter_b(
  input  logic clk,
  input  logic enable,
  input  logic updown,
  input  logic reset_n,
  input  logic areset_n,
  output logic terminal_count_en,
  output logic terminal_count_free,
  output logic [3:0] count
);
  always_ff @(posedge clk or negedge areset_n) begin
    if (!areset_n) count <= 4'd0;
    else if (!reset_n) count <= 4'd0;
    else if (enable) begin
      if (updown) count <= (count == 4'd12) ? 4'd0 : count + 4'd1;
      else count <= (count == 4'd0) ? 4'd12 : count - 4'd1;
    end
  end
  assign terminal_count_free = (updown && (count == 4'd12)) || (!updown && (count == 4'd0));
  assign terminal_count_en = enable && terminal_count_free;
endmodule
SV,
                'explanation' => 'A falla porque terminal_count_en no respeta enable; B es correcta.'
            ),
            array(
                'id' => 'E2',
              'title' => 'Contador B ignora enable en el conteo',
              'summary' => 'Uno de los contadores cambia count incluso cuando enable=0.',
                'truth' => 'a_ok_b_bad',
                'transcript_lines' => array(
                '[E2][stimulus] enable=0 updown=1 reset_n=1 areset_n=1 count_ref=6',
                '[E2][A] count=6 terminal_count_en=0 terminal_count_free=0 -> OK.',
                '[E2][B] count=7 terminal_count_en=0 terminal_count_free=0 -> MISMATCH: count cambia con enable=0.',
                    '[E2][checker] Decision: solo el contador B es erroneo.'
                ),
                'counter_a' => <<<'SV'
module up_down_counter_a(
  input  logic clk,
  input  logic enable,
  input  logic updown,
  input  logic reset_n,
  input  logic areset_n,
  output logic terminal_count_en,
  output logic terminal_count_free,
  output logic [3:0] count
);
  always_ff @(posedge clk or negedge areset_n) begin
    if (!areset_n) count <= 4'd0;
    else if (!reset_n) count <= 4'd0;
    else if (enable) begin
      if (updown) count <= (count == 4'd12) ? 4'd0 : count + 4'd1;
      else count <= (count == 4'd0) ? 4'd12 : count - 4'd1;
    end
  end
  assign terminal_count_free = (updown && (count == 4'd12)) || (!updown && (count == 4'd0));
  assign terminal_count_en = enable && terminal_count_free;
endmodule
SV,
                'counter_b' => <<<'SV'
module up_down_counter_b(
  input  logic clk,
  input  logic enable,
  input  logic updown,
  input  logic reset_n,
  input  logic areset_n,
  output logic terminal_count_en,
  output logic terminal_count_free,
  output logic [3:0] count
);
  always_ff @(posedge clk or negedge areset_n) begin
    if (!areset_n) count <= 4'd0;
    else if (!reset_n) count <= 4'd0;
    else begin
      if (updown) count <= (count == 4'd12) ? 4'd0 : count + 4'd1;
      else count <= (count == 4'd0) ? 4'd12 : count - 4'd1;
    end
  end
  assign terminal_count_free = (updown && (count == 4'd12)) || (!updown && (count == 4'd0));
  assign terminal_count_en = enable && terminal_count_free;
endmodule
SV,
                'explanation' => 'A respeta enable; B cuenta aun con enable=0.'
            ),
            array(
                'id' => 'E3',
                'title' => 'Dos contadores correctos',
                'summary' => 'Ambos contadores respetan enable y los dos resets; la cuenta modulo 13 es correcta.',
                'truth' => 'both_ok',
                'transcript_lines' => array(
                    '[E3][stimulus] enable=1 updown=1 reset_n=1 areset_n=1 count_ref=11',
                    '[E3][A] count=12 terminal_count_en=1 terminal_count_free=1 -> OK.',
                    '[E3][B] count=12 terminal_count_en=1 terminal_count_free=1 -> OK.',
                    '[E3][checker] Decision: los dos contadores son correctos.'
                ),
                'counter_a' => <<<'SV'
module up_down_counter_a(
  input  logic clk,
  input  logic enable,
  input  logic updown,
  input  logic reset_n,
  input  logic areset_n,
  output logic terminal_count_en,
  output logic terminal_count_free,
  output logic [3:0] count
);
  always_ff @(posedge clk or negedge areset_n) begin
    if (!areset_n) count <= 4'd0;
    else if (!reset_n) count <= 4'd0;
    else if (enable) begin
      if (updown) count <= (count == 4'd12) ? 4'd0 : count + 4'd1;
      else count <= (count == 4'd0) ? 4'd12 : count - 4'd1;
    end
  end
  assign terminal_count_free = (updown && (count == 4'd12)) || (!updown && (count == 4'd0));
  assign terminal_count_en = enable && terminal_count_free;
endmodule
SV,
                'counter_b' => <<<'SV'
module up_down_counter_b(
  input  logic clk,
  input  logic enable,
  input  logic updown,
  input  logic reset_n,
  input  logic areset_n,
  output logic terminal_count_en,
  output logic terminal_count_free,
  output logic [3:0] count
);
  always_ff @(posedge clk or negedge areset_n) begin
    if (!areset_n) count <= 4'd0;
    else if (!reset_n) count <= 4'd0;
    else if (enable) begin
      if (updown) count <= (count == 4'd12) ? 4'd0 : count + 4'd1;
      else count <= (count == 4'd0) ? 4'd12 : count - 4'd1;
    end
  end
  assign terminal_count_free = (updown && (count == 4'd12)) || (!updown && (count == 4'd0));
  assign terminal_count_en = enable && terminal_count_free;
endmodule
SV,
                'explanation' => 'Ambos contadores cumplen la especificacion.'
            ),
            array(
                'id' => 'E4',
                'title' => 'Ambos contadores defectuosos',
              'summary' => 'Un fallo afecta terminal_count_free y el otro rompe el modulo 13 (cuenta hasta 13).',
                'truth' => 'both_bad',
                'transcript_lines' => array(
                '[E4][stimulus] fase1: enable=0 updown=1 reset_n=1 areset_n=1 count_ref=12; fase2: enable=1 updown=1 reset_n=1 areset_n=1 count_ref=12',
                    '[E4][A] count=12 terminal_count_en=0 terminal_count_free=0 -> MISMATCH: terminal_count_free depende de enable.',
                '[E4][B] count=13 terminal_count_en=0 terminal_count_free=0 -> MISMATCH: el contador sale del rango 0..12.',
                    '[E4][checker] Decision: ambos contadores son erroneos.'
                ),
                'counter_a' => <<<'SV'
module up_down_counter_a(
  input  logic clk,
  input  logic enable,
  input  logic updown,
  input  logic reset_n,
  input  logic areset_n,
  output logic terminal_count_en,
  output logic terminal_count_free,
  output logic [3:0] count
);
  always_ff @(posedge clk or negedge areset_n) begin
    if (!areset_n) count <= 4'd0;
    else if (!reset_n) count <= 4'd0;
    else if (enable) begin
      if (updown) count <= (count == 4'd12) ? 4'd0 : count + 4'd1;
      else count <= (count == 4'd0) ? 4'd12 : count - 4'd1;
    end
  end
  assign terminal_count_free = enable && ((updown && (count == 4'd12)) || (!updown && (count == 4'd0)));
  assign terminal_count_en = enable && terminal_count_free;
endmodule
SV,
                'counter_b' => <<<'SV'
module up_down_counter_b(
  input  logic clk,
  input  logic enable,
  input  logic updown,
  input  logic reset_n,
  input  logic areset_n,
  output logic terminal_count_en,
  output logic terminal_count_free,
  output logic [3:0] count
);
  always_ff @(posedge clk or negedge areset_n) begin
    if (!areset_n) count <= 4'd0;
    else if (!reset_n) count <= 4'd0;
    else if (enable) begin
      if (updown) count <= (count == 4'd13) ? 4'd0 : count + 4'd1;
      else count <= (count == 4'd0) ? 4'd13 : count - 4'd1;
    end
  end
  assign terminal_count_free = (count == 4'd13);
  assign terminal_count_en = enable && (count == 4'd13);
endmodule
SV,
                'explanation' => 'A gatea mal terminal_count_free; B viola el modulo 13 y alcanza count=13.'
            ),
            array(
                'id' => 'E5',
                'title' => 'Contador B con direccion up/down invertida',
                'summary' => 'El contador B invierte el sentido cuando updown=1; A es correcto.',
                'truth' => 'a_ok_b_bad',
                'transcript_lines' => array(
                    '[E5][stimulus] enable=1 updown=1 reset_n=1 areset_n=1 count_ref=10',
                    '[E5][A] count=11 terminal_count_en=0 terminal_count_free=0 -> OK.',
                    '[E5][B] count=9 terminal_count_en=0 terminal_count_free=0 -> MISMATCH: updown esta invertido.',
                    '[E5][checker] Decision: solo el contador B es erroneo.'
                ),
                'counter_a' => <<<'SV'
module up_down_counter_a(
  input  logic clk,
  input  logic enable,
  input  logic updown,
  input  logic reset_n,
  input  logic areset_n,
  output logic terminal_count_en,
  output logic terminal_count_free,
  output logic [3:0] count
);
  always_ff @(posedge clk or negedge areset_n) begin
    if (!areset_n) count <= 4'd0;
    else if (!reset_n) count <= 4'd0;
    else if (enable) begin
      if (updown) count <= (count == 4'd12) ? 4'd0 : count + 4'd1;
      else count <= (count == 4'd0) ? 4'd12 : count - 4'd1;
    end
  end
  assign terminal_count_free = (updown && (count == 4'd12)) || (!updown && (count == 4'd0));
  assign terminal_count_en = enable && terminal_count_free;
endmodule
SV,
                'counter_b' => <<<'SV'
module up_down_counter_b(
  input  logic clk,
  input  logic enable,
  input  logic updown,
  input  logic reset_n,
  input  logic areset_n,
  output logic terminal_count_en,
  output logic terminal_count_free,
  output logic [3:0] count
);
  always_ff @(posedge clk or negedge areset_n) begin
    if (!areset_n) count <= 4'd0;
    else if (!reset_n) count <= 4'd0;
    else if (enable) begin
      if (updown) count <= (count == 4'd0) ? 4'd12 : count - 4'd1;
      else count <= (count == 4'd12) ? 4'd0 : count + 4'd1;
    end
  end
  assign terminal_count_free = (updown && (count == 4'd12)) || (!updown && (count == 4'd0));
  assign terminal_count_en = enable && terminal_count_free;
endmodule
SV,
                'explanation' => 'A cumple; B invierte la direccion de conteo.'
            )
          ), 0, 5);
    }

    public static function register_rest_routes() {
        register_rest_route('evaluacion-aserciones/v1', '/reports', array(
            'methods' => 'POST',
            'callback' => array(__CLASS__, 'handle_report_submission'),
            'permission_callback' => '__return_true'
        ));
    }

    public static function handle_report_submission(WP_REST_Request $request) {
        $payload = $request->get_json_params();
        if (!is_array($payload)) {
            return new WP_REST_Response(array(
                'ok' => false,
                'message' => 'Payload invalido.'
            ), 400);
        }

        $student = isset($payload['student']) && is_array($payload['student']) ? $payload['student'] : array();
        $student_name = sanitize_text_field((string) ($student['name'] ?? ''));
        $student_email = sanitize_email((string) ($student['email'] ?? ''));
        $student_group = sanitize_text_field((string) ($student['group'] ?? ''));
        $student_subject = sanitize_text_field((string) ($student['subject'] ?? ''));

        if ($student_name === '' || $student_email === '' || $student_group === '' || $student_subject === '') {
          return new WP_REST_Response(array(
            'ok' => false,
            'message' => 'Debes completar nombre, correo institucional, grupo y asignatura.'
          ), 400);
        }

        if (!is_email($student_email)) {
          return new WP_REST_Response(array(
            'ok' => false,
            'message' => 'El correo institucional no es valido.'
          ), 400);
        }

        $wp_user = wp_get_current_user();
        if ($wp_user && $wp_user->exists() && !empty($wp_user->user_email)) {
          if (strtolower($student_email) !== strtolower((string) $wp_user->user_email)) {
            return new WP_REST_Response(array(
              'ok' => false,
              'message' => 'La identidad del envio debe coincidir con el usuario autenticado.'
            ), 403);
          }
        }

        $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field((string) $_SERVER['REMOTE_ADDR']) : 'unknown';
        $throttle_key = 'eva_submit_' . md5(strtolower($student_email) . '|' . $ip);
        if (get_transient($throttle_key)) {
          return new WP_REST_Response(array(
            'ok' => false,
            'message' => 'Espera 90 segundos antes de enviar otro intento.'
          ), 429);
        }
        set_transient($throttle_key, 1, 90);

        $assignments = isset($payload['assignments']) && is_array($payload['assignments']) ? $payload['assignments'] : array();
        if (empty($assignments) && isset($payload['assignment']) && is_array($payload['assignment'])) {
          $assignments = array($payload['assignment']);
        }
        if (empty($assignments)) {
            return new WP_REST_Response(array(
                'ok' => false,
                'message' => 'No se recibieron asignaciones.'
            ), 400);
        }

        $assignment_nonce = 0;
        if (isset($payload['assignment']) && is_array($payload['assignment'])) {
          $assignment_nonce = isset($payload['assignment']['nonce']) ? intval($payload['assignment']['nonce']) : 0;
        }

        if ($assignment_nonce > 0) {
          $existing = get_posts(array(
            'post_type' => 'eva_report',
            'post_status' => 'private',
            'numberposts' => 1,
            'fields' => 'ids',
            'meta_query' => array(
              'relation' => 'AND',
              array(
                'key' => '_eva_report_student_email',
                'value' => strtolower($student_email),
                'compare' => '='
              ),
              array(
                'key' => '_eva_report_assignment_nonce',
                'value' => $assignment_nonce,
                'compare' => '='
              )
            )
          ));

          if (!empty($existing)) {
            return new WP_REST_Response(array(
              'ok' => false,
              'message' => 'Este intento ya fue registrado para tu identificacion.'
            ), 409);
          }
        }

        $student['name'] = $student_name;
        $student['email'] = $student_email;
        $student['group'] = $student_group;
        $student['subject'] = $student_subject;

        $student_label = trim((string) ($student['name'] ?? ''));
        if ($student_label === '' && !empty($student['code'])) {
            $student_label = (string) $student['code'];
        }
        if ($student_label === '' && !empty($student['email'])) {
            $student_label = (string) $student['email'];
        }
        if ($student_label === '') {
            $student_label = 'Sin identificar';
        }

        $score = isset($payload['score']) ? intval($payload['score']) : 0;
        $report_title = 'Eva Report - ' . $student_label . ' - ' . wp_date('Y-m-d H:i:s');
        $report_id = wp_insert_post(array(
            'post_type' => 'eva_report',
            'post_status' => 'private',
            'post_title' => $report_title,
            'post_content' => wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
        ), true);

        if (is_wp_error($report_id)) {
            return new WP_REST_Response(array(
                'ok' => false,
                'message' => $report_id->get_error_message()
            ), 500);
        }

        update_post_meta($report_id, '_eva_report_source', 'evaluacion_aserciones');
        update_post_meta($report_id, '_eva_report_payload', wp_json_encode($payload, JSON_UNESCAPED_UNICODE));
        update_post_meta($report_id, '_eva_report_created_at', current_time('mysql'));
        update_post_meta($report_id, '_eva_report_student', wp_json_encode($student, JSON_UNESCAPED_UNICODE));
        update_post_meta($report_id, '_eva_report_student_email', strtolower($student_email));
        update_post_meta($report_id, '_eva_report_assignment_nonce', $assignment_nonce);
        update_post_meta($report_id, '_eva_report_score', $score);

        return new WP_REST_Response(array(
            'ok' => true,
            'message' => 'Reporte almacenado.',
            'report_id' => $report_id,
            'report_title' => $report_title
        ), 200);
    }

    private static function enqueue_assets() {
        $css_path = plugin_dir_path(__FILE__) . 'assets/css/evaluacion-aserciones.css';
        $js_path = plugin_dir_path(__FILE__) . 'assets/js/evaluacion-aserciones.js';
        $css_ver = file_exists($css_path) ? filemtime($css_path) : '1.0.0';
        $js_ver = file_exists($js_path) ? filemtime($js_path) : '1.0.0';

        wp_enqueue_style(
            'evaluacion-aserciones-style',
            plugin_dir_url(__FILE__) . 'assets/css/evaluacion-aserciones.css',
            array(),
            $css_ver
        );

        wp_enqueue_script(
            'evaluacion-aserciones-script',
            plugin_dir_url(__FILE__) . 'assets/js/evaluacion-aserciones.js',
            array(),
            $js_ver,
            true
        );

        wp_localize_script('evaluacion-aserciones-script', 'EVALUACION_ASERCIONES_CONFIG', array(
            'task_bank' => self::get_task_bank(),
            'report_endpoint' => rest_url('evaluacion-aserciones/v1/reports'),
            'ws_url' => apply_filters('evaluacion_aserciones_ws_url', 'ws://localhost:8000/ws'),
            'surfer_url' => apply_filters('evaluacion_aserciones_surfer_url', 'http://localhost:8000/surfer/index.html'),
            'vcd_base_url' => apply_filters('evaluacion_aserciones_vcd_base_url', 'http://localhost:8000'),
            'current_user' => self::get_current_user_payload()
        ));
    }

    public static function render_shortcode() {
        self::enqueue_assets();

        ob_start();
        ?>
        <div class="evaluacion-aserciones-plugin" id="evaluacion-aserciones-root">
            <div class="eva-student-card">
                <div class="eva-card-title">Identificacion del alumno</div>
                <div class="eva-student-grid">
                    <label>Nombre completo<input id="eva-student-name" type="text" placeholder="Nombre y apellidos"></label>
                  <label>Correo electronico institucional<input id="eva-student-email" type="email" placeholder="correo@institucion.edu"></label>
                    <label>Grupo / clase<input id="eva-student-group" type="text" placeholder="Grupo"></label>
                  <label>Asignatura<input id="eva-student-subject" type="text" placeholder="Asignatura"></label>
                </div>
                <div class="eva-student-meta">Identificador activo: <strong id="eva-student-label">Sin identificar</strong></div>
            </div>

            <div class="eva-assignment-card">
                <div class="eva-card-title">Asignacion aleatoria</div>
              <p>La bateria contiene 5 variantes; a cada alumno le toca 1 caso de forma determinista segun su identificador.</p>
                <div id="eva-assignment-summary" class="eva-summary">Pendiente de asignacion.</div>
                <div class="eva-actions">
                <button type="button" id="eva-refresh-assignment" class="eva-btn primary">Reasignar caso</button>
                    <button type="button" id="eva-generate-transcripts" class="eva-btn secondary">Generar transcript</button>
                    <button type="button" id="eva-submit" class="eva-btn success">Enviar y corregir</button>
                    <button type="button" id="eva-download-report" class="eva-btn secondary">Descargar reporte</button>
                    <button type="button" id="eva-copy-report" class="eva-btn secondary">Copiar reporte</button>
                </div>
                <div id="eva-score" class="eva-score">Puntuacion: 0/10</div>
                <div id="eva-global-feedback" class="eva-feedback"></div>
            </div>

            <div id="eva-task-list" class="eva-task-list"></div>

            <div class="eva-transcript-card">
              <div class="eva-card-title">Registro final de evidencia</div>
              <pre id="eva-transcript" class="eva-transcript">Esperando generacion de evidencia...</pre>
            </div>

            <div id="eva-solution-panel" class="eva-solution-panel hidden"></div>
        </div>
        <?php
        return ob_get_clean();
    }
}

EvaluacionAsercionesPlugin::init();
