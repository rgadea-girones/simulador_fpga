document.addEventListener('DOMContentLoaded', function () {
  const root = document.getElementById('simulador-aserciones-root');
  if (!root) return;

  const listEl = root.querySelector('#sva-example-list');
  const detailEl = root.querySelector('#sva-detail');

  const cfg = (typeof SIMULADOR_ASERCIONES_CONFIG !== 'undefined') ? SIMULADOR_ASERCIONES_CONFIG : {};
  const examplesUrl = cfg.examples_url || '';
  const wsUrl = cfg.ws_url || 'ws://localhost:8000/ws';
  const surferUrl = cfg.surfer_url || 'http://localhost:8000/surfer/index.html';
  const vcdBaseUrl = cfg.vcd_base_url || 'http://localhost:8000';
  const reportEndpoint = cfg.report_endpoint || '';
  const progressStorageKey = 'simulador_aserciones_progress_v1';
  const studentStorageKey = 'simulador_aserciones_student_v1';

  const sim = {
    ws: null,
    currentVcdUrl: null,
    currentVcdFile: null,
    editorsReady: false,
    pendingExample: null,
    exampleToRun: false,
    designEditor: null,
    tbEditor: null
  };

  let examples = [];
  let selectedId = null;
  let progressStore = loadProgressStore();
  let studentProfile = loadStudentProfile();

  function makeClientId() {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') {
      return window.crypto.randomUUID();
    }
    return 'sva-' + Math.random().toString(36).slice(2, 10) + '-' + Date.now().toString(36);
  }

  function loadStudentProfile() {
    const defaults = {
      name: '',
      code: '',
      email: '',
      group: '',
      institution: '',
      clientId: makeClientId()
    };

    try {
      const raw = localStorage.getItem(studentStorageKey);
      const stored = raw ? JSON.parse(raw) : {};
      const merged = Object.assign({}, defaults, (stored && typeof stored === 'object') ? stored : {});
      const wpUser = cfg.current_user || {};
      if (!merged.name && wpUser.display_name) merged.name = wpUser.display_name;
      if (!merged.code && wpUser.user_login) merged.code = wpUser.user_login;
      if (!merged.email && wpUser.user_email) merged.email = wpUser.user_email;
      return merged;
    } catch (_) {
      const wpUser = cfg.current_user || {};
      if (wpUser.display_name) defaults.name = wpUser.display_name;
      if (wpUser.user_login) defaults.code = wpUser.user_login;
      if (wpUser.user_email) defaults.email = wpUser.user_email;
      return defaults;
    }
  }

  function saveStudentProfile(profile) {
    studentProfile = Object.assign({}, studentProfile, profile || {});
    try {
      localStorage.setItem(studentStorageKey, JSON.stringify(studentProfile));
    } catch (_) {
      // Ignorar errores de quota.
    }
  }

  function getStudentLabel() {
    return studentProfile.name || studentProfile.code || studentProfile.email || 'Sin identificar';
  }

  function loadProgressStore() {
    try {
      const raw = localStorage.getItem(progressStorageKey);
      if (!raw) return {};
      const parsed = JSON.parse(raw);
      return (parsed && typeof parsed === 'object') ? parsed : {};
    } catch (_) {
      return {};
    }
  }

  function saveProgressStore() {
    try {
      localStorage.setItem(progressStorageKey, JSON.stringify(progressStore));
    } catch (_) {
      // Ignorar errores de cuota/localStorage bloqueado.
    }
  }

  function getExampleProgress(exampleId) {
    const base = {
      attempt: '',
      checklist: [false, false, false, false],
      confidence: 3,
      score: 0,
      solutionRevealed: false,
      updatedAt: ''
    };
    if (!progressStore[exampleId]) return base;
    return Object.assign(base, progressStore[exampleId]);
  }

  function computeSelfScore(checklist) {
    const checks = Array.isArray(checklist) ? checklist : [];
    const done = checks.filter(Boolean).length;
    return Math.round((done / 4) * 10);
  }

  function buildReportPayload(singleExampleId) {
    const entries = [];
    examples.forEach(function (ex) {
      if (singleExampleId && ex.id !== singleExampleId) return;
      const pr = getExampleProgress(ex.id);
      const entry = {
        id: ex.id,
        title: ex.title,
        difficulty: ex.difficulty,
        attempt: pr.attempt,
        checklist: pr.checklist,
        confidence: pr.confidence,
        score: pr.score,
        solutionRevealed: pr.solutionRevealed,
        updatedAt: pr.updatedAt
      };

      if (!singleExampleId || ex.id === singleExampleId) {
        entry.snapshot = {
          design_sv: getDesignValue(),
          tb_sv: getTbValue()
        };
      }

      entries.push(entry);
    });

    return {
      source: 'simulador_aserciones',
      generatedAt: new Date().toISOString(),
      student: Object.assign({}, studentProfile, {
        label: getStudentLabel(),
        isLoggedInUser: !!(cfg.current_user && cfg.current_user.user_id)
      }),
      entries: entries
    };
  }

  function downloadJson(filename, dataObj) {
    const blob = new Blob([JSON.stringify(dataObj, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  const simNodes = {
    designContainer: root.querySelector('#sva-editor-design'),
    tbContainer: root.querySelector('#sva-editor-tb'),
    consoleEl: root.querySelector('#sva-console'),
    statusBadge: root.querySelector('#sva-status-badge'),
    vcdBadge: root.querySelector('#sva-vcd-badge'),
    runBtn: root.querySelector('#sva-sim-run'),
    clearBtn: root.querySelector('#sva-sim-clear'),
    tabConsoleBtn: root.querySelector('#sva-tab-console'),
    tabVcdBtn: root.querySelector('#sva-tab-vcd'),
    consolePane: root.querySelector('#sva-console-pane'),
    vcdPane: root.querySelector('#sva-vcd-pane'),
    reloadVcdBtn: root.querySelector('#sva-reload-vcd'),
    surferIframe: root.querySelector('#sva-surfer-iframe')
  };

  const defaultDesign = `module dut(input logic clk,input logic rst_n,input logic req,output logic ack);
  logic [1:0] sh;
  always_ff @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin sh<=0; ack<=0; end
    else begin sh<={sh[0],req}; ack<=sh[1]; end
  end
endmodule`;

  const defaultTb = `module tb;
  logic clk=0,rst_n=0,req,ack;
  dut u0(.clk(clk),.rst_n(rst_n),.req(req),.ack(ack));
  always #5 clk=~clk;

  assert property(@(posedge clk) disable iff(!rst_n) req |-> ##2 ack)
    else $error("ACK no llego a tiempo");

  initial begin
    $dumpfile("wave.vcd");
    $dumpvars(0, tb);
    req=0;
    repeat(2) @(posedge clk); rst_n=1;
    @(posedge clk) req<=1;
    @(posedge clk) req<=0;
    repeat(6) @(posedge clk);
    $finish;
  end
endmodule`;

  function normalizeSvCode(rawCode, fallbackCode) {
    const src = (typeof rawCode === 'string' && rawCode.trim()) ? rawCode : fallbackCode;
    if (!src) return '';

    const unescaped = src.replace(/\\n/g, '\n');
    if (unescaped.includes('\n')) {
      return unescaped;
    }

    return formatOneLineSv(unescaped);
  }

  function formatOneLineSv(code) {
    if (!code) return '';

    let text = code.replace(/\s+/g, ' ').trim();

    text = text
      .replace(/;/g, ';\n')
      .replace(/\bmodule\b/g, '\nmodule')
      .replace(/\bendmodule\b/g, '\nendmodule\n')
      .replace(/\bbegin\b/g, 'begin\n')
      .replace(/\bendcase\b/g, '\nendcase')
      .replace(/\bend\b/g, '\nend')
      .replace(/\belse\b/g, '\nelse')
      .replace(/\n{2,}/g, '\n')
      .trim();

    const lines = text.split('\n').map(function (l) { return l.trim(); }).filter(Boolean);
    const out = [];
    let indent = 0;

    lines.forEach(function (line) {
      const lower = line.toLowerCase();
      if (lower.startsWith('end') || lower.startsWith('else') || lower.startsWith('endcase')) {
        indent = Math.max(0, indent - 1);
      }

      out.push('  '.repeat(indent) + line);

      if (lower.endsWith('begin') || lower.startsWith('case ') || lower === 'case') {
        indent += 1;
      }

      if (lower.startsWith('else begin')) {
        indent += 1;
      }
    });

    return out.join('\n');
  }

  function escapeHtml(text) {
    if (text == null) return '';
    return String(text)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/\"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function groupLabel(key) {
    if (key === 'basico') return 'Nivel Basico';
    if (key === 'intermedio') return 'Nivel Intermedio';
    if (key === 'avanzado') return 'Nivel Avanzado';
    return 'Otros';
  }

  function updateStatus(connected) {
    if (!simNodes.statusBadge) return;
    if (connected) {
      simNodes.statusBadge.textContent = 'Conectado';
      simNodes.statusBadge.className = 'sva-status-indicator connected';
    } else {
      simNodes.statusBadge.textContent = 'Desconectado';
      simNodes.statusBadge.className = 'sva-status-indicator disconnected';
    }
  }

  function addLine(message, type) {
    if (!simNodes.consoleEl) return;
    const line = document.createElement('div');
    line.className = 'sva-transcript-line' + (type ? ' ' + type : '');
    line.textContent = message;
    simNodes.consoleEl.appendChild(line);
    simNodes.consoleEl.scrollTop = simNodes.consoleEl.scrollHeight;
  }

  function setTranscript(text, isError) {
    if (!simNodes.consoleEl) return;
    simNodes.consoleEl.innerHTML = '';
    addLine(text, isError ? 'error' : 'ok');
  }

  function switchTab(tabName) {
    if (tabName === 'console') {
      simNodes.tabConsoleBtn.classList.add('active');
      simNodes.tabVcdBtn.classList.remove('active');
      simNodes.consolePane.classList.add('active');
      simNodes.vcdPane.classList.remove('active');
    } else if (tabName === 'vcd' && !simNodes.tabVcdBtn.hasAttribute('disabled')) {
      simNodes.tabVcdBtn.classList.add('active');
      simNodes.tabConsoleBtn.classList.remove('active');
      simNodes.vcdPane.classList.add('active');
      simNodes.consolePane.classList.remove('active');
    }
  }

  function buildAbsoluteUrl(relativeOrAbs) {
    if (!relativeOrAbs) return '';
    if (relativeOrAbs.startsWith('http://') || relativeOrAbs.startsWith('https://')) {
      return relativeOrAbs;
    }
    return vcdBaseUrl.replace(/\/$/, '') + '/' + relativeOrAbs.replace(/^\//, '');
  }

  function enableVcdTab(vcdUrl, vcdFile) {
    sim.currentVcdUrl = buildAbsoluteUrl(vcdUrl);
    sim.currentVcdFile = vcdFile || 'wave.vcd';

    simNodes.tabVcdBtn.removeAttribute('disabled');
    simNodes.tabVcdBtn.classList.remove('disabled');
    simNodes.vcdBadge.textContent = 'Ondas OK';
    simNodes.vcdBadge.className = 'sva-vcd-badge available';
    simNodes.reloadVcdBtn.style.display = 'inline-block';

    function sendLoadCommand() {
      if (!simNodes.surferIframe || !simNodes.surferIframe.contentWindow || !sim.currentVcdUrl) return;
      try {
        simNodes.surferIframe.contentWindow.postMessage({
          command: 'LoadUrl',
          url: sim.currentVcdUrl
        }, '*');
      } catch (e) {
        console.error('Error cargando Surfer', e);
      }
    }

    if (simNodes.surferIframe.src === 'about:blank' || !simNodes.surferIframe.src.includes('/surfer/')) {
      simNodes.surferIframe.src = surferUrl;
      simNodes.surferIframe.onload = function () {
        setTimeout(sendLoadCommand, 800);
      };
    } else {
      sendLoadCommand();
      setTimeout(sendLoadCommand, 600);
    }

    switchTab('vcd');
    addLine('> VCD cargado en Surfer.', 'vcd');
  }

  function disableVcdTab() {
    simNodes.tabVcdBtn.setAttribute('disabled', 'true');
    simNodes.tabVcdBtn.classList.add('disabled');
    simNodes.vcdBadge.textContent = 'Sin VCD';
    simNodes.vcdBadge.className = 'sva-vcd-badge';
    simNodes.reloadVcdBtn.style.display = 'none';
    switchTab('console');
  }

  function getDesignValue() {
    return sim.designEditor ? sim.designEditor.getValue() : defaultDesign;
  }

  function getTbValue() {
    return sim.tbEditor ? sim.tbEditor.getValue() : defaultTb;
  }

  function connectWebSocket() {
    if (sim.ws && sim.ws.readyState === WebSocket.OPEN) return;

    sim.ws = new WebSocket(wsUrl);

    sim.ws.onopen = function () {
      updateStatus(true);
      setTranscript('> Conectado al backend de simulacion.', false);
      sim.ws.send(JSON.stringify({ accion: 'check_vcd' }));
    };

    sim.ws.onclose = function () {
      updateStatus(false);
      setTranscript('> Conexion WebSocket cerrada.', true);
    };

    sim.ws.onerror = function () {
      updateStatus(false);
      setTranscript('> Error de conexion WebSocket.', true);
    };

    sim.ws.onmessage = function (event) {
      let payload;
      try {
        payload = JSON.parse(event.data);
      } catch (error) {
        addLine(event.data, 'ok');
        return;
      }

      if (payload.status === 'error_compilacion' || payload.tipo === 'linter_error') {
        setTranscript(payload.detalles || payload.transcript || 'Error de compilacion.', true);
        disableVcdTab();
        return;
      }

      if (payload.status === 'compilado_ok' || payload.status === 'simulacion_ok') {
        setTranscript(payload.transcript || 'Simulacion ejecutada correctamente.', false);
        if (payload.has_vcd && payload.vcd_url) enableVcdTab(payload.vcd_url, payload.vcd_file);
        else disableVcdTab();
        return;
      }

      if (payload.tipo === 'vcd_status') {
        if (payload.has_vcd && payload.vcd_url) enableVcdTab(payload.vcd_url, payload.vcd_file);
        else disableVcdTab();
        return;
      }

      if (payload.transcript) addLine(payload.transcript, 'ok');
      if (payload.has_vcd && payload.vcd_url) enableVcdTab(payload.vcd_url, payload.vcd_file);
    };
  }

  function runSimulation() {
    const tbCode = getTbValue().trim();
    const designCode = getDesignValue().trim();

    if (!tbCode && !designCode) {
      setTranscript('> Error: paneles vacios.', true);
      return;
    }

    if (!sim.ws || sim.ws.readyState !== WebSocket.OPEN) connectWebSocket();
    if (!sim.ws || sim.ws.readyState !== WebSocket.OPEN) {
      setTranscript('> Backend no disponible.', true);
      return;
    }

    setTranscript('> Iniciando simulacion con QuestaSim...', false);
    sim.ws.send(JSON.stringify({
      accion: 'compilar',
      simulador: 'questasim',
      codigo: designCode || tbCode,
      testbench: tbCode || designCode
    }));
  }

  function applyExampleToEditors(example, autoRun) {
    if (!example) return;

    if (!sim.editorsReady || !sim.designEditor || !sim.tbEditor) {
      sim.pendingExample = example;
      sim.exampleToRun = !!autoRun;
      return;
    }

    sim.designEditor.setValue(normalizeSvCode(example.design_sv, defaultDesign));
    sim.tbEditor.setValue(normalizeSvCode(example.tb_sv, defaultTb));
    setTranscript('> Ejemplo cargado: ' + (example.id || '-') + ' - ' + (example.title || ''), false);

    if (autoRun) {
      setTimeout(runSimulation, 120);
    }
  }

  function initMonacoEditors() {
    if (!simNodes.designContainer || !simNodes.tbContainer) return;

    function createEditors() {
      if (!sim.designEditor) {
        sim.designEditor = monaco.editor.create(simNodes.designContainer, {
          value: defaultDesign,
          language: 'verilog',
          theme: 'vs-dark',
          automaticLayout: true,
          minimap: { enabled: false },
          fontSize: 13,
          scrollBeyondLastLine: false
        });
      }

      if (!sim.tbEditor) {
        sim.tbEditor = monaco.editor.create(simNodes.tbContainer, {
          value: defaultTb,
          language: 'verilog',
          theme: 'vs-dark',
          automaticLayout: true,
          minimap: { enabled: false },
          fontSize: 13,
          scrollBeyondLastLine: false
        });
      }

      sim.editorsReady = true;

      if (sim.pendingExample) {
        const ex = sim.pendingExample;
        const run = sim.exampleToRun;
        sim.pendingExample = null;
        sim.exampleToRun = false;
        applyExampleToEditors(ex, run);
      }
    }

    if (window.monaco && window.monaco.editor) {
      createEditors();
      return;
    }

    const existingLoader = document.querySelector('script[data-sva-monaco="true"]');
    if (existingLoader) {
      existingLoader.addEventListener('load', function () {
        require(['vs/editor/editor.main'], createEditors);
      }, { once: true });
      return;
    }

    const loader = document.createElement('script');
    loader.src = 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.52.2/min/vs/loader.min.js';
    loader.setAttribute('data-sva-monaco', 'true');
    loader.onload = function () {
      require.config({
        paths: { vs: 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.52.2/min/vs' }
      });
      require(['vs/editor/editor.main'], createEditors);
    };
    document.head.appendChild(loader);
  }

  function renderList() {
    if (!listEl) return;

    const groups = { basico: [], intermedio: [], avanzado: [], otros: [] };

    examples.forEach(function (ex) {
      if (groups[ex.difficulty]) groups[ex.difficulty].push(ex);
      else groups.otros.push(ex);
    });

    let html = '';
    ['basico', 'intermedio', 'avanzado', 'otros'].forEach(function (g) {
      if (!groups[g].length) return;
      html += '<div class="sva-group-label">' + groupLabel(g) + '</div>';
      groups[g].forEach(function (ex) {
        const active = ex.id === selectedId ? ' active' : '';
        html += '<button class="sva-example-btn' + active + '" data-id="' + escapeHtml(ex.id) + '">';
        html += '<span class="sva-example-id">' + escapeHtml(ex.id) + '</span>';
        html += '<span class="sva-example-title">' + escapeHtml(ex.title) + '</span>';
        html += '</button>';
      });
    });

    listEl.innerHTML = html;

    listEl.querySelectorAll('.sva-example-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        const id = this.getAttribute('data-id');
        selectExample(id);
      });
    });
  }

  function renderDetail(example) {
    if (!detailEl || !example) return;

    const concepts = Array.isArray(example.concepts) ? example.concepts : [];

    const progress = getExampleProgress(example.id);
    const solvedHint = progress.attempt.trim().length > 0;

    detailEl.innerHTML = '' +
      '<h3>' + escapeHtml(example.id + ' - ' + example.title) + '</h3>' +
      '<div class="sva-meta"><strong>Dificultad:</strong> ' + escapeHtml(example.difficulty || 'n/a') + '</div>' +
      '<div><strong>Teoria breve:</strong> ' + escapeHtml(example.theory || '') + '</div>' +
      '<div style="margin-top:8px;"><strong>Conceptos:</strong><br>' +
      concepts.map(function (c) { return '<span class="sva-chip">' + escapeHtml(c) + '</span>'; }).join('') +
      '</div>' +
      '<div class="sva-student-box">' +
      '<h4>Identificacion del alumno</h4>' +
      '<p>Este bloque identifica al estudiante en el reporte guardado.</p>' +
      '<div class="sva-student-grid">' +
      '<label>Nombre completo<input id="sva-student-name" type="text" value="' + escapeHtml(studentProfile.name || '') + '" placeholder="Nombre y apellidos"></label>' +
      '<label>Codigo o matricula<input id="sva-student-code" type="text" value="' + escapeHtml(studentProfile.code || '') + '" placeholder="Codigo de alumno"></label>' +
      '<label>Correo electronico<input id="sva-student-email" type="email" value="' + escapeHtml(studentProfile.email || '') + '" placeholder="correo@dominio.edu"></label>' +
      '<label>Grupo / clase<input id="sva-student-group" type="text" value="' + escapeHtml(studentProfile.group || '') + '" placeholder="Grupo"></label>' +
      '<label>Centro / institucion<input id="sva-student-institution" type="text" value="' + escapeHtml(studentProfile.institution || '') + '" placeholder="Institucion"></label>' +
      '</div>' +
      '<div class="sva-student-meta">Identificador activo: <strong id="sva-student-label">' + escapeHtml(getStudentLabel()) + '</strong></div>' +
      '</div>' +
      '<div class="sva-practice-box">' +
      '<h4>Ejercicio</h4>' +
      '<p>' + escapeHtml(example.exercise || '') + '</p>' +
      '<label for="sva-attempt"><strong>Tu intento</strong></label>' +
      '<textarea id="sva-attempt" class="sva-attempt" placeholder="Escribe aqui tu propuesta antes de ver la solucion...">' + escapeHtml(progress.attempt) + '</textarea>' +
      '<div class="sva-rubric">' +
      '<div><strong>Autoevaluacion (marca lo cumplido)</strong></div>' +
      '<label><input type="checkbox" class="sva-check" data-idx="0" ' + (progress.checklist[0] ? 'checked' : '') + '> Entiendo el objetivo temporal de la propiedad</label>' +
      '<label><input type="checkbox" class="sva-check" data-idx="1" ' + (progress.checklist[1] ? 'checked' : '') + '> Mi codigo compila y simula</label>' +
      '<label><input type="checkbox" class="sva-check" data-idx="2" ' + (progress.checklist[2] ? 'checked' : '') + '> Justifico por que la asercion detecta el error</label>' +
      '<label><input type="checkbox" class="sva-check" data-idx="3" ' + (progress.checklist[3] ? 'checked' : '') + '> Propongo al menos un caso erroneo</label>' +
      '</div>' +
      '<div class="sva-confidence">' +
      '<label for="sva-confidence-range"><strong>Confianza:</strong> <span id="sva-confidence-value">' + escapeHtml(String(progress.confidence)) + '/5</span></label>' +
      '<input id="sva-confidence-range" type="range" min="1" max="5" step="1" value="' + escapeHtml(String(progress.confidence)) + '">' +
      '</div>' +
      '<div class="sva-score">Puntuacion de autoevaluacion: <strong id="sva-score-value">' + escapeHtml(String(progress.score || 0)) + '/10</strong></div>' +
      '<div class="sva-practice-actions">' +
      '<button class="sva-btn secondary" id="sva-save-progress">Guardar progreso</button>' +
      '<button class="sva-btn secondary" id="sva-export-progress">Descargar reporte</button>' +
      '<button class="sva-btn secondary" id="sva-copy-progress">Copiar reporte</button>' +
      '<button class="sva-btn secondary" id="sva-send-progress">Enviar reporte</button>' +
      '<button class="sva-btn success" id="sva-reveal-solution" ' + (solvedHint ? '' : 'disabled') + '>Ver solucion</button>' +
      '<button class="sva-btn secondary" id="sva-hide-solution">Ocultar solucion</button>' +
      '</div>' +
      '<div id="sva-progress-status" class="sva-progress-status"></div>' +
      '<div id="sva-solution-box" class="sva-solution-box' + (progress.solutionRevealed ? '' : ' hidden') + '">' +
      '<h4>Solucion guiada</h4>' +
      '<p>' + escapeHtml(example.solution || '') + '</p>' +
      '</div>' +
      '</div>' +
      '<div class="sva-actions">' +
      '<button class="sva-btn primary" id="sva-load-btn">Cargar ejemplo en el simulador</button>' +
      '<button class="sva-btn success" id="sva-load-run-btn">Cargar y ejecutar</button>' +
      '<button class="sva-btn secondary" id="sva-copy-btn">Copiar JSON</button>' +
      '</div>';

    const loadBtn = detailEl.querySelector('#sva-load-btn');
    const loadRunBtn = detailEl.querySelector('#sva-load-run-btn');
    const copyBtn = detailEl.querySelector('#sva-copy-btn');
    const studentNameEl = detailEl.querySelector('#sva-student-name');
    const studentCodeEl = detailEl.querySelector('#sva-student-code');
    const studentEmailEl = detailEl.querySelector('#sva-student-email');
    const studentGroupEl = detailEl.querySelector('#sva-student-group');
    const studentInstitutionEl = detailEl.querySelector('#sva-student-institution');
    const studentLabelEl = detailEl.querySelector('#sva-student-label');
    const attemptEl = detailEl.querySelector('#sva-attempt');
    const checks = Array.from(detailEl.querySelectorAll('.sva-check'));
    const confidenceRange = detailEl.querySelector('#sva-confidence-range');
    const confidenceValue = detailEl.querySelector('#sva-confidence-value');
    const scoreValue = detailEl.querySelector('#sva-score-value');
    const saveProgressBtn = detailEl.querySelector('#sva-save-progress');
    const exportProgressBtn = detailEl.querySelector('#sva-export-progress');
    const copyProgressBtn = detailEl.querySelector('#sva-copy-progress');
    const sendProgressBtn = detailEl.querySelector('#sva-send-progress');
    const revealBtn = detailEl.querySelector('#sva-reveal-solution');
    const hideBtn = detailEl.querySelector('#sva-hide-solution');
    const solutionBox = detailEl.querySelector('#sva-solution-box');
    const progressStatus = detailEl.querySelector('#sva-progress-status');

    function setProgressStatus(msg, isError) {
      if (!progressStatus) return;
      progressStatus.textContent = msg;
      progressStatus.className = 'sva-progress-status' + (isError ? ' error' : ' ok');
    }

    function syncStudentLabel() {
      const label = getStudentLabel();
      if (studentLabelEl) studentLabelEl.textContent = label;
      return label;
    }

    function readStudentFromUI() {
      return {
        name: studentNameEl ? studentNameEl.value.trim() : '',
        code: studentCodeEl ? studentCodeEl.value.trim() : '',
        email: studentEmailEl ? studentEmailEl.value.trim() : '',
        group: studentGroupEl ? studentGroupEl.value.trim() : '',
        institution: studentInstitutionEl ? studentInstitutionEl.value.trim() : '',
        clientId: studentProfile.clientId || makeClientId()
      };
    }

    function persistStudentFromUI() {
      saveStudentProfile(readStudentFromUI());
      syncStudentLabel();
      return studentProfile;
    }

    function readCurrentProgressFromUI() {
      const checklist = [false, false, false, false];
      checks.forEach(function (ch) {
        const idx = Number(ch.getAttribute('data-idx'));
        if (idx >= 0 && idx < checklist.length) checklist[idx] = !!ch.checked;
      });

      const confidence = confidenceRange ? Number(confidenceRange.value || 3) : 3;
      const score = computeSelfScore(checklist);

      return {
        student: readStudentFromUI(),
        attempt: attemptEl ? attemptEl.value : '',
        checklist: checklist,
        confidence: confidence,
        score: score,
        solutionRevealed: solutionBox ? !solutionBox.classList.contains('hidden') : false,
        updatedAt: new Date().toISOString()
      };
    }

    function persistCurrentProgress() {
      const next = readCurrentProgressFromUI();
      progressStore[example.id] = next;
      saveProgressStore();
      if (scoreValue) scoreValue.textContent = String(next.score) + '/10';
      if (confidenceValue) confidenceValue.textContent = String(next.confidence) + '/5';
      const canReveal = next.attempt.trim().length >= 20;
      if (revealBtn) revealBtn.disabled = !canReveal;
      return next;
    }

    if (confidenceRange && confidenceValue) {
      confidenceRange.addEventListener('input', function () {
        confidenceValue.textContent = String(confidenceRange.value) + '/5';
      });
    }

    checks.forEach(function (ch) {
      ch.addEventListener('change', function () {
        const score = computeSelfScore(readCurrentProgressFromUI().checklist);
        if (scoreValue) scoreValue.textContent = String(score) + '/10';
      });
    });

    if (attemptEl) {
      attemptEl.addEventListener('input', function () {
        const enable = attemptEl.value.trim().length >= 20;
        if (revealBtn) revealBtn.disabled = !enable;
      });
    }

    if (saveProgressBtn) {
      saveProgressBtn.addEventListener('click', function () {
        persistStudentFromUI();
        const saved = persistCurrentProgress();
        setProgressStatus('Progreso guardado. Puntuacion: ' + String(saved.score) + '/10.', false);
      });
    }

    if (exportProgressBtn) {
      exportProgressBtn.addEventListener('click', function () {
        persistStudentFromUI();
        persistCurrentProgress();
        const payload = buildReportPayload(example.id);
        downloadJson('reporte_' + example.id + '.json', payload);
        setProgressStatus('Reporte descargado.', false);
      });
    }

    if (copyProgressBtn) {
      copyProgressBtn.addEventListener('click', function () {
        persistStudentFromUI();
        persistCurrentProgress();
        const payload = buildReportPayload(example.id);
        navigator.clipboard.writeText(JSON.stringify(payload, null, 2)).then(function () {
          setProgressStatus('Reporte copiado al portapapeles.', false);
        }).catch(function () {
          setProgressStatus('No se pudo copiar el reporte.', true);
        });
      });
    }

    if (sendProgressBtn) {
      sendProgressBtn.addEventListener('click', function () {
        persistStudentFromUI();
        persistCurrentProgress();
        if (!reportEndpoint) {
          setProgressStatus('No hay endpoint configurado. Usa Descargar o Copiar reporte.', true);
          return;
        }

        const payload = buildReportPayload(example.id);
        sendProgressBtn.disabled = true;
        sendProgressBtn.textContent = 'Enviando...';
        fetch(reportEndpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }).then(function (resp) {
          return resp.json().then(function (data) {
            if (!resp.ok || !data || !data.ok) {
              throw new Error((data && data.message) ? data.message : ('HTTP ' + resp.status));
            }
            const label = data.report_id ? ('Reporte almacenado #' + data.report_id + '.') : 'Reporte almacenado.';
            setProgressStatus(label, false);
          });
        }).catch(function (err) {
          setProgressStatus('No se pudo enviar el reporte: ' + err.message + '. Puedes descargarlo localmente.', true);
        }).finally(function () {
          sendProgressBtn.disabled = false;
          sendProgressBtn.textContent = 'Enviar reporte';
        });
      });
    }

    if (revealBtn && solutionBox) {
      revealBtn.addEventListener('click', function () {
        persistCurrentProgress();
        solutionBox.classList.remove('hidden');
        persistCurrentProgress();
        setProgressStatus('Solucion visible. Revisa y compara con tu intento.', false);
      });
    }

    if (hideBtn && solutionBox) {
      hideBtn.addEventListener('click', function () {
        solutionBox.classList.add('hidden');
        persistCurrentProgress();
        setProgressStatus('Solucion oculta.', false);
      });
    }

    [studentNameEl, studentCodeEl, studentEmailEl, studentGroupEl, studentInstitutionEl].forEach(function (field) {
      if (!field) return;
      field.addEventListener('input', function () {
        persistStudentFromUI();
      });
    });

    syncStudentLabel();

    if (loadBtn) {
      loadBtn.addEventListener('click', function () {
        applyExampleToEditors(example, false);
        const simPanel = root.querySelector('.sva-sim-plugin');
        if (simPanel) simPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
    }

    if (loadRunBtn) {
      loadRunBtn.addEventListener('click', function () {
        applyExampleToEditors(example, true);
        const simPanel = root.querySelector('.sva-sim-plugin');
        if (simPanel) simPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
    }

    if (copyBtn) {
      copyBtn.addEventListener('click', function () {
        const text = JSON.stringify(example, null, 2);
        navigator.clipboard.writeText(text).then(function () {
          copyBtn.textContent = 'Copiado';
          setTimeout(function () { copyBtn.textContent = 'Copiar JSON'; }, 1500);
        }).catch(function () {
          copyBtn.textContent = 'No se pudo copiar';
          setTimeout(function () { copyBtn.textContent = 'Copiar JSON'; }, 1500);
        });
      });
    }
  }

  function selectExample(id) {
    selectedId = id;
    const ex = examples.find(function (item) { return item.id === id; });
    renderList();
    renderDetail(ex);
  }

  function wireSimulatorButtons() {
    if (simNodes.tabConsoleBtn) {
      simNodes.tabConsoleBtn.addEventListener('click', function () {
        switchTab('console');
      });
    }

    if (simNodes.tabVcdBtn) {
      simNodes.tabVcdBtn.addEventListener('click', function () {
        switchTab('vcd');
      });
    }

    if (simNodes.runBtn) {
      simNodes.runBtn.addEventListener('click', runSimulation);
    }

    if (simNodes.clearBtn) {
      simNodes.clearBtn.addEventListener('click', function () {
        setTranscript('> Consola limpia.', false);
        disableVcdTab();
        if (sim.designEditor) sim.designEditor.setValue(defaultDesign);
        if (sim.tbEditor) sim.tbEditor.setValue(defaultTb);
      });
    }

    if (simNodes.reloadVcdBtn) {
      simNodes.reloadVcdBtn.addEventListener('click', function () {
        if (sim.currentVcdUrl) enableVcdTab(sim.currentVcdUrl, sim.currentVcdFile);
      });
    }
  }

  function initExamples() {
    if (!examplesUrl) {
      listEl.innerHTML = '<div class="sva-error">No se encontro URL de ejemplos.</div>';
      return;
    }

    fetch(examplesUrl)
      .then(function (resp) {
        if (!resp.ok) throw new Error('HTTP ' + resp.status);
        return resp.json();
      })
      .then(function (data) {
        if (!Array.isArray(data) || data.length === 0) throw new Error('Catalogo vacio');
        examples = data;
        selectedId = data[0].id;
        renderList();
        renderDetail(data[0]);
      })
      .catch(function (err) {
        listEl.innerHTML = '<div class="sva-error">No se pudieron cargar los ejemplos: ' + escapeHtml(err.message) + '</div>';
      });
  }

  initMonacoEditors();
  connectWebSocket();
  wireSimulatorButtons();
  initExamples();
});
