<?php
/**
 * Plugin Name: Simulador SystemVerilog - Has-A / Is-A v1.0
 * Description: Entorno de simulación de 3 frames (Testbench, Design y Transcript) para aprender conceptos de OOP con SystemVerilog.
 * Version: 1.0.0
 * Author: Tu Nombre
 */

if (!defined('ABSPATH')) {
    exit;
}

class SimuladorHasAIsA_Plugin {

    public function __construct() {
        add_shortcode('simulador_has_a_is_a', array($this, 'render_shortcode'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
    }

    public function enqueue_assets() {
        wp_enqueue_script(
            'simulador-has-a-is-a-editor',
            plugin_dir_url(__FILE__) . 'assets/js/editor-has-a-is-a.js',
            array(),
            '1.0.0',
            true
        );

        wp_localize_script('simulador-has-a-is-a-editor', 'SV_HAS_A_IS_A_CONFIG', array(
            'ws_url' => apply_filters('simulador_has_a_is_a_ws_url', 'ws://localhost:8000/ws')
        ));
    }

    public function render_shortcode() {
        ob_start();
        ?>
        <style>
          .sim-spinner {
            display: inline-block;
            width: 12px;
            height: 12px;
            border: 2px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: #ffffff;
            animation: sim-spin 0.8s linear infinite;
            margin-right: 6px;
            vertical-align: middle;
          }

          @keyframes sim-spin {
            to { transform: rotate(360deg); }
          }

          .sim-btn {
            border: none;
            padding: 6px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            font-size: 13px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            white-space: nowrap;
            transition: opacity 0.2s;
          }

          .sim-btn:hover {
            opacity: 0.9;
          }

          .sim-btn:disabled {
            background-color: #7f8c8d !important;
            cursor: not-allowed;
            opacity: 0.75;
          }
        </style>

        <div class="simulador-fpga-wrapper" style="max-width: 1400px; margin: 20px auto; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">
            
            <!-- BARRA SUPERIOR DE ESTADO Y BOTONES -->
            <div style="background-color: #2c3e50; color: white; padding: 10px 16px; border-radius: 8px 8px 0 0; display: flex; justify-content: space-between; align-items: center; border: 2px solid #333; border-bottom: none; gap: 15px; flex-wrap: wrap;">
                
                <!-- TÍTULO Y SELECCIÓN DE EJEMPLOS DESDE POWERPOINT -->
                <div style="font-weight: bold; font-size: 15px; white-space: nowrap; flex-shrink: 0; display: flex; align-items: center; gap: 8px;">
                    🛠️ <span>Simulador OOP SystemVerilog (Has-A / Is-A)</span>
                    <select id="ejemplos-has-a-is-a" style="margin-left: 15px; font-size: 12px; padding: 4px 8px; border-radius: 4px; background: #34495e; color: white; border: 1px solid #7f8c8d; cursor: pointer;">
                        <optgroup label="Conceptos Básicos">
                            <option value="clases">1. Clases (Slide 3)</option>
                            <option value="objetos">2. Objetos (Slide 4)</option>
                            <option value="constructor_sin_args">3. Constructor sin Argumentos (Slide 5 Izq)</option>
                            <option value="constructor_con_args">4. Constructor con Argumentos (Slide 5 Der)</option>
                            <option value="gestion_memoria">5. Gestión de Memoria (Slide 6)</option>
                        </optgroup>
                        <optgroup label="Miembros Estáticos y Constantes">
                            <option value="variables_estaticas">6. Variables de Clase Estáticas (Slide 8)</option>
                            <option value="variables_constantes">7. Variables de Clase Constantes (Slide 9)</option>
                            <option value="metodos_estaticos">8. Métodos Estáticos (Slide 10)</option>
                        </optgroup>
                        <optgroup label="Encapsulamiento y Relaciones">
                            <option value="encapsulacion">9. Ocultación y Encapsulación (Slide 11)</option>
                            <option value="relacion_has_a">10. Subclases - Relación "Has a" (Slide 13)</option>
                            <option value="relacion_is_a">11. Clases Derivadas - Relación "Is a" (Slide 14)</option>
                            <option value="downcasting">12. Downcasting con $cast (Slide 16)</option>
                        </optgroup>
                        <optgroup label="Copia y Polimorfismo">
                            <option value="shallow_copy">13. Shallow Copy / Copia Superficial (Slide 18)</option>
                            <option value="deep_copy">14. Deep Copy / Copia Profunda (Slide 20)</option>
                            <option value="clonado">15. Clonado con .clone() (Slide 22)</option>
                            <option value="metodos_virtuales">16. Métodos Virtuales y Polimorfismo (Slide 23)</option>
                        </optgroup>
                    </select>
                </div>

                <!-- ESTADO Y ACCIONES -->
                <div style="display: flex; align-items: center; gap: 8px; flex-shrink: 0;">
                    <span id="estado_ws" style="font-size: 12px; font-weight: bold; color: #f1c40f; white-space: nowrap; margin-right: 6px;">
                        🟠 Conectando...
                    </span>
                    
                    <button id="btn-linter" class="sim-btn" style="background-color: #e67e22; color: white;">
                        🔍 Comprobar (Linter)
                    </button>

                    <button id="btn-compilar" class="sim-btn" style="background-color: #2980b9; color: white;">
                        <span id="btn-spinner-compilar" class="sim-spinner" style="display: none;"></span>
                        <span id="btn-compilar-texto">✅ Verificar</span>
                    </button>

                    <button id="btn-simular" class="sim-btn" style="background-color: #27ae60; color: white;">
                        <span id="btn-spinner-simular" class="sim-spinner" style="display: none;"></span>
                        <span id="btn-simular-texto">▶️ Simular</span>
                    </button>
                </div>
            </div>

            <!-- INTERFACE DE 3 FRAMES -->
            <div style="display: flex; flex-direction: column; gap: 10px; background-color: #1a252f; padding: 10px; border: 2px solid #333; border-radius: 0 0 8px 8px;">
                
                <!-- PARTE SUPERIOR: DOS COLUMNAS (TESTBENCH Y DISEÑO) -->
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                    
                    <!-- Frame 1: Banco de Pruebas (Testbench) -->
                    <div style="border: 1px solid #444; border-radius: 6px; overflow: hidden; background-color: #1e1e1e;">
                        <div style="background-color: #34495e; color: #ecf0f1; padding: 6px 12px; font-weight: bold; font-size: 13px;">
                            🧪 Banco de Pruebas (Testbench)
                        </div>
                        <div id="editor_tb" style="height: 380px; width: 100%;"></div>
                    </div>

                    <!-- Frame 2: Módulo de Diseño (Design) -->
                    <div style="border: 1px solid #444; border-radius: 6px; overflow: hidden; background-color: #1e1e1e;">
                        <div style="background-color: #34495e; color: #ecf0f1; padding: 6px 12px; font-weight: bold; font-size: 13px;">
                            📄 Módulo de Diseño (Design)
                        </div>
                        <div id="editor_design" style="height: 380px; width: 100%;"></div>
                    </div>

                </div>

                <!-- PARTE INFERIOR: TRANSCRIPT DEL SIMULADOR (ANCHO COMPLETO) -->
                <div style="border: 1px solid #444; border-radius: 6px; overflow: hidden; background-color: #0f1419;">
                    <div style="background-color: #34495e; color: #ecf0f1; padding: 6px 12px; font-weight: bold; font-size: 13px; display: flex; justify-content: space-between;">
                        <span>💻 Console Transcript (QuestaSim / Icarus)</span>
                        <span id="transcript-status" style="font-weight: normal; font-size: 11px; color: #bdc3c7;">Esperando acción...</span>
                    </div>
                    <div id="simulation-transcript" style="height: 300px; width: 100%; padding: 10px; font-family: 'Consolas', 'Courier New', monospace; font-size: 12px; color: #2ecc71; overflow-y: auto; box-sizing: border-box; white-space: pre-wrap; background-color: #0d1117; border-top: 1px solid #222;">
// La salida de la compilación y simulación aparecerá aquí...
                    </div>
                </div>

            </div>

        </div>
        <?php
        return ob_get_clean();
    }
}

new SimuladorHasAIsA_Plugin();
